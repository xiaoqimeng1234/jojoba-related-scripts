use strict;
#use warnings;

my @species=("Vvi", "Aya", "Sch");
my @blast=("Vvi_Vvi", "Aya_Aya", "Sch_Sch", "Vvi_Aya", "Vvi_Sch", "Aya_Sch", "Sch_Aya", "Sch_Vvi", "Aya_Vvi");

my %hash;
for (my $i=0; $i<=$#blast; $i++) {$hash{$blast[$i]}=1;}
my $num=$#species+1;
for (my $i=0; $i<$num; $i++)
{
	my $db=$species[$i];
	system "makeblastdb -in $db.pep -dbtype prot -parse_seqids -out $db.db";
	print  "makeblastdb -in $db.pep -dbtype prot -parse_seqids -out $db.db\n";
	for (my $j=0; $j<$num; $j++)
	{
		my $seq=$species[$j];
		#print "$seq\_$db\n";
		my $blast_name="$species[$j]\_$species[$i]";
		if( exists($hash{$blast_name}) )
		{
			print  "\nblastp -query $seq.pep -out $seq\_$db.blast -db $db.db -outfmt 6 -evalue 1e-5 -max_target_seqs 10 -num_threads 8\n";
			system "blastp -query $seq.pep -out $seq\_$db.blast -db $db.db -outfmt 6 -evalue 1e-5 -max_target_seqs 10 -num_threads 8";
		}
	}
}
