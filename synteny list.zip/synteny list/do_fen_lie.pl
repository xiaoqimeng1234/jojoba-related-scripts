use strict;

open (IN, "Vvi.txt") or die;
open (OUT1, ">Vvi.1.txt") or die;
open (OUT2, ">Vvi.2.txt") or die;

my $gene;
while (<IN>)
{
    my @array=split(/\,/,$_);
    #print "$array[1]\n";
    if ($array[1]=~/Vvi/)
    { print OUT1 "$array[0]\t$array[1]\n";}
    if ($array[2]=~/Vvi/)
    { print OUT2 "$array[0]\t$array[2]\n";}


}



