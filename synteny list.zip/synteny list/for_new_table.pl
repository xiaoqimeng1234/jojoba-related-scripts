use strict;

open (IN,"Vvi_Aya_Sch.txt") or die;
open (GENE,"Vvi.$ARGV[0].txt") or die;
open (OUT,">$ARGV[0].Vvi_Aya_Sch.txt") or die;

my %hash;
while (<GENE>)
{
	my @array=split(/\s+/,$_);
	$hash{$array[0]}=$array[1];
}
my %data;
while (<IN>)
{
	my $gene=$_;
	$gene=~s/\n//g;
	my @array=split(/\s+/,$_);
	$data{$array[0]}=$gene;
}

close IN;
open (IN,"Vvi_Aya_Sch.txt") or die;

while (<IN>)
{
	my @array=split(/\s+/,$_);
	if ( exists($hash{$array[0]}) )
	{
		my $gene=$hash{$array[0]};
		print OUT "$data{$array[0]}\t\|\t$data{$gene}\n";
	}
	else {print OUT "$data{$array[0]}\t\|\t.\t.\t.\t.\t.\n"}
}