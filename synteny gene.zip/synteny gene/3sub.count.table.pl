use strict;
my @files=glob "*.rr.txt";
my  @dirname;
my %hash;
foreach(@files){$hash{$_}=1;
#`2new_length.pl $_`;
#`del $_`;
}
my @specials= qw(Vvi Sch);
for (my $n=0;$n<=$#specials;$n++)
    {my $name1="new.".$specials[$n]."_".$specials[$n].".remove_tandem.block.rr.txt";
	    if (exists $hash{$name1})
	    {push @dirname,$name1;}
    }

for (my  $i=0;$i<=$#specials;$i++)
   {for (my $j=$i+1;$j<=$#specials;$j++)
        {
	   my  $name="new.".$specials[$i]."_".$specials[$j].".block.rr.txt";
	   if (exists $hash{$name})
	   {push @dirname,$name;}
	   else
	   {$name="new.".$specials[$j]."_".$specials[$i].".block.rr.txt";
		 if (exists $hash{$name})
	    {push @dirname,$name;}
	   
	   }
        }
  }
  print $#dirname;
&countgene(@dirname);
sub countgene()
{my @yujg=qw(4 10 20 50);

foreach my $filename(@_){
foreach my $yujigao(@yujg)
{
my $file=$filename;
open(IN, $file) or die "cannot opeen $file due to $!.";
open (OUT,">>out$yujigao.txt")or die "out.txt can not open due to $!";
my $title = "";
my $grlinenum = 0;
my $blocklen = 0;
my $blocknum = 0;
my $pvalue = 0;
my $genepairnum = 0;
my $longestblocklen = 0;
my $chropair = "";
my $longestblock = "";
my %hash1;
my %hash2;
my %hash3;
my @abcd=split(/\./,$file);
my @abc=split (/_/,$abcd[1]);
print OUT "$file\t";
while(<IN>)
{
  $_ =~ s/[\n\r]//g;
  if($_ =~ /^the/)
  {
    $title = $_;
    my @line = split(/\s+/, $_);
    $blocklen = $line[$#line];
    $grlinenum = 0;
  }
 
  elsif ( $_ =~ /\D+\d+g/i and $blocklen >= $yujigao)
  {
    $grlinenum ++;
    my @line = split(/\s+/, $_);
	my @chr1 = split(/g/,$line[0]);
	my @chr2 = split(/g/,$line[2]);
	if ($abc[0] eq $abc[1]){$hash3{$line[0]}=1;$hash3{$line[2]}=1;}
	else{
	$hash1{$line[0]}=1;
	$hash2{$line[2]}=1;}

    $chropair = $chr1[0]."-".$chr2[0];
  }
  elsif($_ =~ /^>/)
  {
    my @line = split(/\s+/, $_);
    $pvalue = $line[$#line];
    if($grlinenum > 0 && $blocklen >= $yujigao)
    {
      $blocknum ++;
      $genepairnum += $blocklen;
      #print $blocknum."\t".$chropair."\t".$blocklen."\t".$pvalue."\n";
      if($blocklen > $longestblocklen)
      {$longestblocklen = $blocklen; $longestblock =$chropair."\t".$longestblocklen."\n";}
    }
  }
}
my $genenum=keys(%hash3);
my $gene1=keys(%hash1);
my $gene2=keys(%hash2);
my $everage;
if ($blocknum==0){$everage="-"}
else{ $everage=$genepairnum/$blocknum;}
#printf  "%12.2f\t", $everage."\t";
#print  "$gene1-$gene2\t$genepairnum/$blocknum\t$longestblock\n";
printf OUT "%12.2f\t", $everage."\t";
if ($abc[0] eq $abc[1]){print OUT "$genenum\t$genepairnum/$blocknum\t$longestblock";}
else{
print OUT "$gene1 vs $gene2\t$genepairnum/$blocknum\t$longestblock";}
close IN;
close OUT;
}
}
}
#print "total gene2 num is ".$gene2."\n";}
#print "total block num is ".$blocknum."\n";
#print "longest block is ".$longestblock."\n";
#print "total gene pair num is ".$genepairnum."\n";
