use strict;
my @files=glob "*.txt";
for (my $i=0;$i<=$#files;$i++)
{


open (IN,"$files[$i]") or die;
open (OUT,">new.$files[$i]") or die;
my $pairnum;
my @block;
my $old;
while (<IN>)
{
chomp;

if ($_=~/\d+[Gg]/)
{
$pairnum++;
if ($pairnum==1)
{
push @block,$old;

}

push @block,$_;
}
$old=$_;
if ($_=~/>LOCALE/)
{push @block,$_;
if ($block[1]=~/\d+[Gg]/ and $pairnum>=$ARGV[0])
{

	for(my $i=0;$i<=$#block;$i++)
	{
	$block[$i]=~s/length\s+\d+/length $pairnum/;
	print OUT "$block[$i]\n";
	}
}
	@block=();
	$pairnum=0;
}
}
close IN;
close OUT;
`del $files[$i]`;
}
