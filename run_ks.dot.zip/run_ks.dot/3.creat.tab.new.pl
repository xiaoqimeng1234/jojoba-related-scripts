use strict;

my $ks_file = "$ARGV[0]\_$ARGV[1]_block_rr.ks.new.txt";
open(KS,$ks_file) or die "can not open ks file $ks_file due to $!.\n";

my $colinear_file = "$ARGV[0]\_$ARGV[1].block.rr.txt";
open(CF,$colinear_file) or die "can not open cf file $colinear_file due to $!.\n";

my $out_colinear_file = "$ARGV[0]\_$ARGV[1]_block_rr.latest.txt";
open(OUT,">".$out_colinear_file) or die "can not open cf file $out_colinear_file due to $!.\n";
my %pair_ks;
my %pair_order;
while(<KS>)
{
	$_ =~s/[\n\r]//g;
	my @array = split(/\t/,$_);
	my $pair = $array[0]."_".$array[1];
	$pair_ks{$pair} = $array[3];
	$pair_order{$pair} = $array[4]
}

while(<CF>)
{
	$_ =~s/[\n\r]//g;
	my @arr = split(/\s+/,$_);
	if($_ !~/$ARGV[0]/){print OUT$_."\n";next;}

	my $pair1 = $arr[0]."_".$arr[2];

	print OUT $_."\n".$arr[0]."\t".$arr[2]."\t1\t".$pair_ks{$pair1}."\t".$pair_order{$pair1}."\n";
	
}
