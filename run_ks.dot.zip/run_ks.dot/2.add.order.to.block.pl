use strict;

my $order_file = "$ARGV[0]\_$ARGV[1].blastp.new.order.m8";
open(OD,$order_file) or die "can not open ks file $order_file due to $!.\n";

my $ks_file = "$ARGV[0]\_$ARGV[1].ks.txt";
open(KS,$ks_file) or die "can not open cf file $ks_file due to $!.\n";

my $outfile = "$ARGV[0]\_$ARGV[1]_block_rr.ks.new.txt";
open(OUT,">",$outfile) or die "can not open out file $outfile due to $!.\n";

my %hash;
while(<OD>)
{
	$_ =~s/[\n\r]//g;
	my @array = split(/\t/,$_);
	$hash{$array[0]}=$array[1];
}
while(<KS>)
{
	$_ =~s/[\n\r]//g;
	my @arr= split(/\t/,$_);
	print OUT $arr[0]."\t".$arr[1]."\t".$arr[2]."\t".$arr[3]."\t".$hash{$arr[0]}."\n"
}

`perl 3.creat.tab.new.pl $ARGV[0] $ARGV[1]`