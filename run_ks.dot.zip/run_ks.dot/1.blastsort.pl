use strict;

my $blastfile = "$ARGV[0]\_$ARGV[1].blast";
open(BLAST,$blastfile) or die "can not open blast file $blastfile due to $!.\n";

my $outfile = "$ARGV[0]\_$ARGV[1].blastp.new.order.m8";
open(OUT,">",$outfile) or die "can not open out file $outfile due to $!.\n";
my @genename=();
my $i=0;
while(<BLAST>)
{
	$_ =~s/[\n\r]//g;
	my @array = split(/\t/,$_);
	$genename[$i] = $array[0];
	$i++;
}
my $number = -1;
my @chr_num = (-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,);
for(my $n=0;$n<=$#genename;$n++)
{
	
	if($genename[$n] ne $genename[$n+1])
	{	my $lastnumber = 1+$number;

		print OUT $genename[$n]."\t".$lastnumber."\n";
		$number =-1;}
	else{	$number++;
		print OUT $genename[$n]."\t".$number."\n";}
}
`perl 2.add.order.to.block.pl $ARGV[0] $ARGV[1]`