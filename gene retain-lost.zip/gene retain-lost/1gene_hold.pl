#!usr/bin/perl -w
use strict;
open IN,"$ARGV[0]"|| die "$!";##mc文件
open OUT,">$ARGV[1].alignment.txt" or die "$!";##alignment文件
my @array;
my $n=1;
my $chr;
while(<IN>){
	chomp;
    if($_ =~ /caffold/){next;}
    if($_ =~ /\d+s\d+/){next;}
	my @arr=split/\,/,$_;
    my ($ch)=$arr[0] =~ /\D+(\d*)g/;##基因名分割g/G
	if($n==1){$chr=$ch}
	#print "$chr\n";
	if(eof){
		for(my $i=0;$i<=$#arr;$i++){
			if($i==0){next;}
			elsif($i==$#arr){next;}
			else{
				if($arr[$i] =~ /\w+/){$arr[$i]=1;}
				if($arr[$i] eq '.'){$arr[$i]=0;}
			}
		}
		push @array,[@arr];
		my @data;
		for(my $i=0;$i<=$#array;$i++){			
			my $flag=0;
			for(my $j=1;$j<=$#arr-1;$j++){
				#print "$array[$i][$j]\t";
				if($array[$i][$j] =~ /\d/){
					$data[$j-1][0]+=$array[$i][$j];
					$data[$j-1][1]+=1;
					$flag+=$array[$i][$j];
					#print "$array[$i][$j]\t1\n";
				}
			}
			if($array[$i][$#arr] >0){
				$data[$#arr-1][1]+=1;
				if($flag > 0){$data[$#arr-1][0]+=1;}
			}
			#print "\n";
		}
		print OUT "$chr\t";
		$#data=$#arr-2;
		for(my $i=0;$i<=$#data;$i++){
			#print "$data[$i][0]\t$data[$i][1]\n";
			my $lv;
			if(defined($data[$i])){$lv=$data[$i][0]/$data[$i][1];}
			else{$lv=0;}
			print OUT "$lv\t";
		}
		print OUT "\n";
	}
	if($chr eq $ch){
		for(my $i=0;$i<=$#arr;$i++){
			if($i==0){next;}
			elsif($i==$#arr){next;}
			else{
				if($arr[$i] =~ /^\w+/){$arr[$i]=1;}
				if($arr[$i] eq '.'){$arr[$i]=0;}
			}
		}
		push @array,[@arr];
	        if($#array==99){
			my @data;
			for(my $i=0;$i<=$#array;$i++){
				my $flag=0;
				for(my $j=1;$j<=$#arr-1;$j++){
					#print "$array[$i][$j]\t";
					if($array[$i][$j] =~ /\d/){
						$data[$j-1][0]+=$array[$i][$j];
	               				$data[$j-1][1]+=1;
					        $flag+=$array[$i][$j];
					        #print "$array[$i][$j]\t1\n";
					}
				}
				if($array[$i][$#arr] >0){
					$data[$#arr-1][1]+=1;
				        if($flag > 0){$data[$#arr-1][0]+=1;}
				}
			}
			print OUT "$chr\t";
			$#data=$#arr-2;
			for(my $i=0;$i<=$#data;$i++){
				#print "$data[$i][0]\t$data[$i][1]\n";
			        my $lv;
				if(defined($data[$i])){$lv=$data[$i][0]/$data[$i][1];}
			        else{$lv=0;}
			        print OUT "$lv\t";
			}
			print OUT "\n";
			$#array=-1;
		}
		
	}
	else{
		my @data;
		for(my $i=0;$i<=$#array;$i++){
			my $flag=0;
			for(my $j=1;$j<=$#arr-1;$j++){
				#print "$array[$i][$j]\t";
				if($array[$i][$j] =~ /\d/){
					$data[$j-1][0]+=$array[$i][$j];
	        			$data[$j-1][1]+=1;
		         	        $flag+=$array[$i][$j];
				        #print "$array[$i][$j]\t1\n";
				}
			}
			if($array[$i][$#arr] >0){
				$data[$#arr-1][1]+=1;
			        if($flag > 0){$data[$#arr-1][0]+=1;}
			}
		}
		print OUT "$chr\t";
		$#data=$#arr-2;
		for(my $i=0;$i<=$#data;$i++){
			#print "$data[$i][0]\t$data[$i][1]\n";
		        my $lv;
		        if(defined($data[$i])){$lv=$data[$i][0]/$data[$i][1];}
		        else{$lv=0;}
		        print OUT "$lv\t";
		}
		print OUT "\n";
		$chr=$ch;
		$#array=-1;
		for(my $i=0;$i<=$#arr;$i++){
			if($i==0){next;}
			elsif($i==$#arr){next;}
			else{
				if($arr[$i] =~ /\w+/){$arr[$i]=1;}
				if($arr[$i] eq '.'){$arr[$i]=0;}
			}
		}
		push @array,[@arr];
	}
	$n+=1;
}
close IN;
