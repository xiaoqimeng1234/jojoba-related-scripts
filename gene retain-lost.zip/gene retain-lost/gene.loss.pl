#!usr/bin/perl -w
use strict;
open MT,"$ARGV[0]"or die "$!";#input lens
my %hash;
while(<MT>){
	chomp;
	my @arr=split;
	$hash{$arr[0]}=$arr[1];
}
close MT;
open IN,"$ARGV[1]"|| die "$!";#input mc txt
open OUT,">$ARGV[2]" or die "$!";
my @loss;
my @array;
my $chr=1;
while(<IN>){
	chomp;
    if($_ =~ /caffold/){next;}
    if($_ =~ /\d+s\d+/){next;}
	my @arr=split/\,/,$_;
	my ($chr1)=$arr[0] =~ /\D+(\d*)g/;#g/G
	if(eof){
		for(my $i=0;$i<=$#arr;$i++){
			if($i==0){next;}
			elsif($i==$#arr){next;}
			else{
				if($arr[$i] =~ /\w+/){$arr[$i]=1;}
				if($arr[$i] eq '.'){$arr[$i]=0;}
			}
		}
		push @array,[@arr];
		my $n=$#{$array[0]};
		my @data;
		for(my $i=0;$i<=$#array;$i++){			
			my $flag=0;
			for(my $j=1;$j<=$n-1;$j++){
				if($array[$i][$j] =~ /\d/){
					$data[$j-1][0]+=$array[$i][$j];
					$data[$j-1][1]+=1;
					$flag+=$array[$i][$j];
				}
			}
			if($array[$i][$n] >0){
				$data[$n-1][1]+=1;
				if($flag > 0){$data[$n-1][0]+=1;}
			}
		}
        my $chrlens=$#array+1;
		print OUT "$chr\t$chrlens\t";
		for(my $i=0;$i<=$#data;$i++){
			my $lv;
			if(defined($data[$i])){$lv=1-$data[$i][0]/$data[$i][1];}
			else{$lv=1;}
			print OUT "$lv\t";
		}
		print OUT "\n";
	}
	if($chr == $chr1){
		for(my $i=0;$i<=$#arr;$i++){
			if($i==0){next;}
			elsif($i==$#arr){next;}
			else{
				if($arr[$i] =~ /^\w+/){$arr[$i]=1;}
				if($arr[$i] eq '.'){$arr[$i]=0;}
			}
		}
		
		push @array,[@arr];
	}
	else{
		my $n=$#{$array[0]};
		my @data;
		for(my $i=0;$i<=$#array;$i++){			
			my $flag=0;
			for(my $j=1;$j<=$n-1;$j++){
				if($array[$i][$j] =~ /\d/){
					$data[$j-1][0]+=$array[$i][$j];
					$data[$j-1][1]+=1;
					$flag+=$array[$i][$j];
				}
			}
			if($array[$i][$n] >0){
				$data[$n-1][1]+=1;
				if($flag > 0){$data[$n-1][0]+=1;}
			}
		}
		my $chrlens=$#array+1;
		print OUT "$chr\t$chrlens\t";
		for(my $i=0;$i<=$#data;$i++){
			my $lv;
			if(defined($data[$i])){$lv=1-$data[$i][0]/$data[$i][1];}
			else{$lv=1;}
			print OUT"$lv\t";
		}
		print OUT "\n";
		$chr=$chr1;
		$#array=-1;
		for(my $i=0;$i<=$#arr;$i++){
			if($i==0){next;}
			elsif($i==$#arr){next;}
			else{
				if($arr[$i] =~ /\w+/){$arr[$i]=1;}
				if($arr[$i] eq '.'){$arr[$i]=0;}
			}
		}
		push @array,[@arr];
	}
}
close IN;
close OUT;
open OUT1,"$ARGV[2]" or die "$!";
while(<OUT1>){
	chomp;
	my @arr=split;
	push @loss,[@arr];
}
close OUT;
@loss=sort{$a->[0] <=> $b->[0]} @loss;
open OUT,">$ARGV[2]" or die "$!";
foreach (@loss){
	print OUT join("\t", @$_), "\n";
}
