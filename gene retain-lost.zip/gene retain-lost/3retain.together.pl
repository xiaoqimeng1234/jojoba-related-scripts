#!usr/bin/perl -w
use strict;
open IN,$ARGV[0] or die "$!";#mc.txt
my @array;
my @mc;
while(<IN>){
	chomp;
	my @arr=split/\,/,$_;
	push @mc,[@arr];
	my ($ch)=$arr[0] =~ /\D+(\d*)[g|G]/;
	my @a;
	for my $i(1..$#arr-1){
	    push @a,$arr[$i];
	}
	push @array,[$ch,@a];
}
close IN;
my @retain_exp=();
my @retain=();
for my $i (0..$#array){
    my $chr=$array[$i][0];
	$retain_exp[$i][0]=$chr;
	$retain[$i][0]=$chr;
    for my $j (1..$#{$array[$i]}){
	    my $start=$i-50;
	    my $end=$i+50;
	    my $num_gene=0;
		my $retain_num=0;
	    my $exp_gene=0;
		my $ave_exp=0;
		my $length=0;
	    for($start..$end){
		    if($_ < 0 or  $_ > $#array or $array[$_][0] ne $chr){next;}
			if($mc[$_][$j] =~ /\w+/){$retain_num+=1;}
			$length+=1;
	    }
		my $ave_retain=$retain_num/$length;
        $retain[$i][$j]=$ave_retain;		
		#print "$chr\t$num_gene\t$ave_exp\n";
	}  
}
open OUT,">".$ARGV[1] or die "$!";##retain文件
print OUT "chr\tretain1\tretain2\tretain3\n";#\tretain3\tretain4
for my $i (0..$#retain){
    #print(“@$retain[$i]\t","\n");
	print OUT "$retain[$i][0]\t$retain[$i][1]\t$retain[$i][2]\t$retain[$i][3]\n";#\t$retain[$i][3]\t$retain[$i][4]
}


