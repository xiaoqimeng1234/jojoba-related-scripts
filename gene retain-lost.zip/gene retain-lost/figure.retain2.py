#!/usr/bin/env python
# -*- coding: utf-8 -*-
from sympy import * #调用处理数字符号的sympy库
from matplotlib.pyplot import * #调用绘图matplotlib库
from numpy import *
import sys
figure(figsize=(10,12))
root = axes([0, 0, 1, 1])
f1=open(sys.argv[1])  #retain.loss
chr_len=9
data=[[] for i in range((chr_len+1))]

num=0
top2=0
for line in f1.readlines():
    a=[]
    a=line.split()
    num+=1
    if num==1:
        continue
    if int(a[0])-10 > 0:
        a=[float(k) for k in a]
        data[int(a[0])-10].append(a)
        if(max(a[1:]) > top2):
            top2=max(a[1:]) 
    #print(a[0])
    #if a[0] is chr:
    #    data.append(a)
    #    num+=1
        #print(a)
f1.close()

x_self=0.86
y_self=0.86
x_s=0.09
y_s=0.09
#top1=max(max([float(k[1]) for k in data]),max([float(k[3]) for k in data]))
#top2=max(max([float(k[2]) for k in data]),max([float(k[4]) for k in data]))
#a=max(max([max(k)[1:] for k in data if len(k) > 1]))
#print(a)
#top2=max(max([max(k)[1:] for k in data if len(k) > 1]))
top1=max([len(k) for k in data])
print(top1,top2)
p_x=x_self/float(top1)
p_y1=y_self/float(top2)/chr_len
p_y2=y_self/float(top2)/chr_len
print(p_y1,p_y2)
xlab=0
align = dict(family='Times New Roman',style='italic')

ylab=0
for i in range(0,40):
    if ylab>float(top2):
        break
    #text(x_s-0.03,y_s+ylab*p_y2-0.03*p_y2+0.5*y_self,str(round(ylab,2)).rjust(3),color='k',fontsize=6)
    #plot([x_s-0.005,x_s],[y_s+ylab*p_y2+0.5*y_self,y_s+ylab*p_y2+0.5*y_self],color='k',lw=1)
    ylab+=10
X=[]
Y1=[]
Y2=[]
Y3=[]
Y4=[]
Y5=[]
Y6=[]
def plotline(n,x1,x2,y1,y2,color):
    y1=y_s+(chr_len-n)/chr_len*y_self+y1
    y2=y_s+(chr_len-n)/chr_len*y_self+y2
    plot([x1,x2],[y1,y2],color=color,lw=1)
def plotyaxis(n):
    ylab=0
    y0=y_s+(chr_len-n)/chr_len*y_self
    for i in range(0,100):
        if ylab>float(top2)*100:
            break
        text(x_s-0.025,y0+0.01*ylab*p_y1-0.012*p_y1,str(round(ylab,2)).rjust(3),color='k',fontsize=10)
        plot([x_s-0.005,x_s],[y0+0.01*ylab*p_y1,y0+0.01*ylab*p_y1],color='k',lw=1)
        ylab+=10############ y lab text
len_chr=0
for k in data:
    if len(k) < 1:
        continue	
    x=x_s+0.9*x_self
    y=y_s+(chr_len-int(k[1][0])+0.6+10)/chr_len*y_self
    text(x,y,'Vv'+str(int(k[0][0])),color='black',fontsize=22,**align)
    plotyaxis(int(k[0][0])-10)
    for i in range(len(k)-1):
        if k[i][0] != k[i+1][0]:
            len_chr=i
            continue
        x1=float(i-len_chr)*p_x+x_s
        x2=float(i+1-len_chr)*p_x+x_s
        y1=float(k[i][1])*p_y1
        y2=float(k[i+1][1])*p_y1
        y3=float(k[i][2])*p_y1
        y4=float(k[i+1][2])*p_y1
        y5=float(k[i][3])*p_y1
        y6=float(k[i+1][3])*p_y1
        #y7=float(k[i][4])*p_y1
        #y8=float(k[i+1][4])*p_y1
        #y5=(y1+y3)/2
        #y6=(y2+y4)/2
        if(float(k[i][1])>0 and float(k[i+1][1])>0):
            plotline(int(k[i][0])-10,x1,x2,y1,y2,'red')
        if(float(k[i][2])>0 and float(k[i+1][2])>0):
            plotline(int(k[i][0])-10,x1,x2,y3,y4,'blue')
        if(float(k[i][3])>0 and float(k[i+1][3])>0):
            plotline(int(k[i][0])-10,x1,x2,y5,y6,'green')
        #if(float(k[i][4])>0 and float(k[i+1][4])>0):
            #plotline(int(k[i][0])-10,x1,x2,y7,y8,'black')
        #plotline(int(k[i][0]),x1,x2,y5,y6,'green')

#plot([0.85,0.85+100*p_x],[0.86,0.86],color='black',lw=1.5)
#text(0.828,0.87,'100 Genes'.center(10),color = "black",fontsize=12,rotation = 0,**align)
plot([0.71,0.71+100*p_x],[0.91,0.91],color='black',lw=1.5)
text(0.695,0.92,'100 Genes'.center(10),color = "black",fontsize=18,rotation = 0,**align)
#plot(X,Y1,color='gold',lw=1)
#plot(X,Y2,color='blue',lw=1)
#plot(X,Y3,color='green',lw=1)
#plot(X,Y4,color='red',lw=1)
#plot1 = plot(data, data1, 'r',label = 'Paralogous block 1',linewidth = 2,color = 'r')# use pylab to plot x and y : Give your plots names

for i in range(0,chr_len+1):
    plot([x_s,x_s+x_self],[y_s+y_self*i/chr_len,y_s+y_self*i/chr_len],'k',linewidth = 1)
plot([x_s+x_self,x_s+x_self],[y_s,y_s+y_self],'k',linewidth = 1)
plot([x_s,x_s],[y_s,y_s+y_self],'k',linewidth = 1)


#plot([x_s+x_self*0.8,x_s+x_self*0.82],[y_s+y_self1*0.8,y_s+y_self1*0.8],color='red',lw=6)
#text(x_s+x_self*0.83,y_s+y_self1*0.78,'Paralogous block 1',color = "black",fontsize=9,rotation = 0,**align)
#plot([x_s+x_self*0.8,x_s+x_self*0.82],[y_s+y_self1*0.7,y_s+y_self1*0.7],color='black',lw=6)
#text(x_s+x_self*0.83,y_s+y_self1*0.68,'Gene expression ',color = "black",fontsize=9,rotation = 0,**align)


#text(0.05,0.4,'Gene retain',color = "black",fontsize=12,rotation = 90,**align)
#text(0.05,0.76,'Gene expression',color = "black",fontsize=12,rotation = 90,**align)
#text(0.03,0.6,'Gene retention',color = "black",fontsize=20,rotation = 90,**align)
text(0.03,0.3,'Percent retained in Simmondsia chinensis',color = "black",fontsize=24,rotation = 90,**align)
#text(0.09,0.06,'Paralogous block 1',color = "black",fontsize=13,rotation = 0,**align)
#text(0.3,0.06,'Paralogous block 2',color = "black",fontsize=13,rotation = 0,**align)
#text(0.51,0.06,'Paralogous block 3',color = "black",fontsize=13,rotation = 0,**align)
#text(0.72,0.06,'Paralogous block 4',color = "black",fontsize=13,rotation = 0,**align)
#plot([0.25,0.265],[0.065,0.065],'red',linewidth = 3)
#plot([0.46,0.475],[0.065,0.065],'blue',linewidth = 3)
#plot([0.67,0.685],[0.065,0.065],'green',linewidth = 3)
#plot([0.88,0.895],[0.065,0.065],'gold',linewidth = 3)
#title='Medicago Chromosome'
#text(0.25,0.93,title.center(50),color = "black",fontsize=25,rotation = 0,**align)
root.set_xlim(0,1)
root.set_ylim(0,1)
root.set_axis_off()
savefig('Vvi_Sch.retain.22'+'.png',dpi = 800)
rcdefaults()
#show()# show the plot on the screen
