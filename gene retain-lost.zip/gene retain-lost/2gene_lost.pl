#!usr/bin/perl -w
use strict;
open IN,"$ARGV[0]" || die "$!";##mc文件
open OUT,">$ARGV[1]" or die "$!";##lost文件
my @array;
my $n=0;
while(<IN>){
	chomp;
	if($_ =~ /caffold/){next;}
    if($_ =~ /\d+s\d+/){next;}
	my @arr=split/\,/,$_;
	$n=$#arr;
	$arr[0]=~m /\d+/;
	$arr[0]=$&;
	push @array,[@arr];
}
close IN;
my @all;
for(my $i=1;$i<=$n-1;$i++){
	my $a=0;
	my $chr;
	for(my $j=0;$j<=$#array;$j++){
		if($j==0){$chr=$array[$j][0];}
		if($array[$j][$i] eq ' '){next;}
		if($array[$j][$i]!~ /\d+/ && $array[$j][0]==$chr){
			$a+=1;
		}
		else{
			#print "$a\n";
			push @all,$a;
			$chr=$array[$j][0];
			$a=0;
			push @all,$a;
		}
		if($j==$#array){push @all,$a;}
	}
}
my %hash;
foreach (@all){
	$hash{$_}++;
}
foreach my $key (sort  { $a <=> $b } keys %hash) {
	print OUT "$key\t$hash{$key}\n";
}

