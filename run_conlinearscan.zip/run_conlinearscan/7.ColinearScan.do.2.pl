use strict;

### input chromosome length
my $A_lens;
my $B_lens;
opendir TMP, "./bed" ||die "dir $!";
foreach my $key (readdir TMP){
	if($key =~ m/$ARGV[0]/ && $key =~ m/lens/){$A_lens = $key;}
	if($key =~ m/$ARGV[1]/ && $key =~ m/lens/){$B_lens = $key;}
}
my @chro1len = read_chrolen($A_lens);
my @chro2len = read_chrolen($B_lens);
my $block = $ARGV[0]."_".$ARGV[1].".block";
my $pair = $ARGV[0]."_all_".$ARGV[1]."_all.pair";
my $chr1 = $ARGV[0];
my $chr2 = $ARGV[1];
my $chr1_num = $ARGV[2];
my $chr2_num = $ARGV[3];
`mkdir $block`;

for(my $i=1; $i<=$chr1_num; $i++)
{
   for(my $j=1; $j<=$chr2_num; $j++)#different species
   {
       my $pairsfile = "$pair/$chr1.$i.$chr2.$j.pair";
       my $blockfile = "$block/$chr1.$i.$chr2.$j.blk";

print $pairsfile."\n".$blockfile."\n".$chro1len[$i-1]." ".$chro2len[$j-1]."\n";

       system("blockscan -chr1len $chro1len[$i-1] -chr2len $chro2len[$j-1] -mg1 50 -mg2 50 $pairsfile > $blockfile");
   }
}

sub read_chrolen()
{
   open(IN, "./bed/$_[0]") or die "cannot open $_[0] due to $!\n";
   my $lineno = 0;
   my @chrolen;
   while(<IN>)
   {
      $_ =~ s/[\n\r]//g;
      my @arr = split(/\s+/, $_);
      $chrolen[$arr[0]-1] = $arr[1];
      $lineno ++;
   }
   close($_[0]);

   return(@chrolen);
}
