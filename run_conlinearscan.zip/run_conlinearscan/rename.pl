
foreach my $file  (glob "./blastp/*blast")
{
    
    my $newFile=$file;
    $newFile =~ s/\_/\./g;
    rename $file,$newFile;
    print "$file  -->  $newFile\n";
}
