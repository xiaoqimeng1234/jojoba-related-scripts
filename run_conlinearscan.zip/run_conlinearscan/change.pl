my $file = $ARGV[0]."_all_".$ARGV[1]."_all.pairs_1";
system("sed -i s/\+/1/g $file");
system("sed -i s/\-/-1/g $file");
