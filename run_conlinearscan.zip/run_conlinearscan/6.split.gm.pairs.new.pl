use strict;

my $pairsfile = $ARGV[0];
open(PA,$pairsfile) or die "can not open pairs file  due to $!.\n";

my @species = split(/\./,$pairsfile);
my $dir = $species[0].".pair";
my $chr1 = $ARGV[1];
my $chr2 = $ARGV[2];

`mkdir $dir`;
#system(mkdir $dir);
my $outfile;
while(<PA>)
{
	$_ =~s/[\n\r]//g;
	my @array = split(/\s+/,$_);
	my @a = split(/g|B/,$array[0]);
	my $brchr = $a[0];
	$brchr =~s/^\D+//g;
	$brchr =~s/^[0+]//g;
	my @id1 = split(/g/,$brchr);
	$brchr =$id1[0];

	my @b = split(/g|B/,$array[3]);
	my $vvchr = $b[0];
	$vvchr =~s/^\D+//g;
	$vvchr =~s/^[0+]//g;
	my @id2 = split(/g|B/,$vvchr);
	$vvchr =$id2[0];
    #$outfile = $species[0].".pair"."\\vv_chr$brchr"."_br_chr$vvchr".".pair";
         my $file_name = $chr1.".".$brchr.".".$chr2.".".$vvchr.".pair";
    $outfile = "$dir/$file_name";
         #print $id1[0]."\t$a[0] 11111\n";
    open(OUT,">>",$outfile) or die "can not open out file $outfile due to $!.\n";
    print OUT "$_\n";
}
