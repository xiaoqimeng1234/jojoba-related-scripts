use strict;

my @blastname;
my $brgfffile;
my $vvgfffile;
my $pesupairsfile;

opendir TMP, "./bed" ||die "dir $!";
foreach my $key (readdir TMP){
	if($key =~ m/$ARGV[0]/ && $key =~ m/gff/g){
		$brgfffile = $key;
	}
	if($key =~ $ARGV[1] && $key =~ m/gff/g){
		$vvgfffile = $key;
	}
}
if($ARGV[0] eq $ARGV[1]){
	$vvgfffile = $brgfffile;
}
opendir OMG, "./." ||die "dir $!";
foreach my $key (readdir OMG){
	if($key =~ m/$ARGV[0]/ && $key =~ $ARGV[1] && $key =~ m/blastp/g){
		$pesupairsfile = $key;
	}
}
open(BRGF,"./bed/$brgfffile") or die "can not open brgff file $brgfffile due to $!.\n";

open(VVGF,"./bed/$vvgfffile") or die "can not open vvgff file $vvgfffile due to $!.\n";

open(PESU,$pesupairsfile) or die "can not open pesupairs file $pesupairsfile due to $!.\n";

my $outfile = $ARGV[0]."_all_".$ARGV[1]."_all.pairs";
open(OUT,">",$outfile) or die "can not open out file $outfile due to $!.\n";

my %hash;
print $brgfffile."\t".$vvgfffile."\t".$pesupairsfile."\n";
while(<BRGF>)
{
	$_ =~s/[\n\r]//g;
	my @array = split(/\s+/,$_);
	#print $array[0]."gff1\n";
	$hash{$array[0]} =$array[1]." ".$array[2];
}

while(<VVGF>)
{
	$_ =~s/[\n\r]//g;
	my @item = split(/\s+/,$_);
	#print $item[0] ."gff2\n";
	$hash{$item[0]}=$item[1]." ".$item[2];
}

while(<PESU>)
{
	$_ =~s/[\n\r]//g;
	my @arr = split(/\s+/,$_);
	print OUT$arr[0]." ".$hash{$arr[0]}." ".$arr[1]." ".$hash{$arr[1]}."\n";
}
#unlink $pesupairsfile;