use strict;

my @blastname;
my $name1 = "$ARGV[0].$ARGV[1]";
#my $name2 = "$ARGV[1].$ARGV[0]";
opendir TMP, "./blastp" ||die "dir $!";
foreach my $key (readdir TMP){
	if($key =~ $name1){
	#if($key =~ $name1 || $key =~ $name2){
		print $key."\n";
		open(BL,"./blastp/$key") or die "can not open blast file $key due to $!.\n";
		my $outfile =  $ARGV[0].".".$ARGV[1].".blastp";
		open(OUT,">",$outfile) or die "can not open out file $outfile due to $!.\n";
		while(<BL>)
		{	
			
			s/Chr//g;
			s/_/g/g;
			s/Contig//g;
			if(/Un/ ||  /Scaffold/ || /random/){next;}
			$_ =~s/[\n\r]//g;
			my @array = split(/\s+/,$_);
			if($array[0]!~/$ARGV[0]/ || $array[1]!~/$ARGV[1]/ ){next;}
			#print "$array[0]  $array[1]\n";
			if($array[11]<100){next;}
			print OUT  "$_"."\n";
		}
	last;
	}
}



