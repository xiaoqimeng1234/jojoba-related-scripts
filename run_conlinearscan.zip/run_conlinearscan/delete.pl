use strict;


open(IN,"$ARGV[0]\_all\_$ARGV[1]_all.pairs") or die "can not open blast file purged_file due to $!.\n";
open(OUT,">$ARGV[0]\_all\_$ARGV[1]_all.pairs_1") or die "can not open out file outfile due to $!.\n";
while(<IN>)
{	
chomp;
	my @array = split(/\s+/,$_);
	if(!exists($array[4])){next;}
	print OUT  "$_\n";
}



