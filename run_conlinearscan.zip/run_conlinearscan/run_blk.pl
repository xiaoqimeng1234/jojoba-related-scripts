use strict;

system("perl rename.pl");
sub run_Col{
print $_[0]."\t".$_[1]."\t".$_[2]."\t".$_[3]."\n";
my $game;
my $dir;
    system ("perl 1.get.puse.pairs.pl $_[0] $_[1]");
    system("perl 2.get.pairs.pl $_[0] $_[1]");
    system("perl delete.pl $_[0] $_[1]");
    system("perl change.pl $_[0] $_[1]");
    my $purged = $_[0]."_all_".$_[1]."_all.purged";
    my $pairs = $_[0]."_all_".$_[1]."_all.pairs_1";
    system("cat $pairs | perl repeat_mask.pl -n 50 > $purged");
    system("perl 6.split.gm.pairs.new.pl $purged $_[0] $_[1]");
    if($_[0] eq $_[1])
    {
        system("perl 7.ColinearScan.do.2.pl $_[0] $_[1] $_[2] $_[3]");
        system("perl 7.ColinearScan.do.1.pl $_[0] $_[1] $_[2] $_[3]");
        system("perl 8.remove.redundancy.in.colinearscan.blocks.pl $_[0] $_[1] 1");
        system("perl 8.remove.redundancy.in.colinearscan.blocks.pl $_[0] $_[1] 0");
        $game = $_[0]."_".$_[1].".partially.block.rr.txt";
        $dir = "$_[0]_$_[1].partially.block.rr";
        system("cat ./$dir/*.rr > ./blk/$game");
        $game = $_[0]."_".$_[1].".block.rr.txt";
        $dir = "$_[0]_$_[1].block.rr";
        system("cat ./$dir/*.rr > ./blk/$game");

	}
    else
    {
        system("perl 7.ColinearScan.do.2.pl $_[0] $_[1] $_[2] $_[3]");
        system("perl 8.remove.redundancy.in.colinearscan.blocks.pl $_[0] $_[1] 0");
        $game = $_[0]."_".$_[1].".block.rr.txt";
        $dir = "$_[0]_$_[1].block.rr";
        system("cat ./$dir/*.rr > ./blk/$game");
	}
	system("rm -rf $_[0]*");
}

my @blastname;
opendir TMP, "./blastp" ||die "dir $!";
my $num1 = 1;
my $num2 = 1;
my $re;
foreach(readdir TMP){
if(/^\./){next;}
if(/^rename.pl/){next;}
if(/less/){next;}
    my @arr = split(/\./);
    #my @array = split(/2/,$arr[2]);
    #if($arr[0] ne $array[1]){next;}
    open(IN1,"./bed/$arr[0].lens");
    while(<IN1>)
    {
        chomp;
        my @arrs = split(/\t/);
        #$arrs[0] = substr($arrs[0],3,);
        if($arrs[0] > $num1){$num1 = $arrs[0];}
    }
    open(IN2,"./bed/$arr[1].lens");
    while(<IN2>)
    {
        chomp;
        my @arrs = split(/\t/);
        #$arrs[0] = substr($arrs[0],3,);
        if($arrs[0] > $num2){$num2 = $arrs[0];}
    }
    if($arr[0] eq $arr[1]){$re = 1;}
    else{$re = 0;}
    print $arr[0]."\t".$arr[1]."\t".$num1."\t".$num2."\t".$re."\n"; 
    push(@blastname,$arr[0],$arr[1],$num1,$num2,$re);
	$num1 = 1;
	$num2 = 1;
	run_Col(@blastname);
    @blastname = ();
    undef @blastname;
}
