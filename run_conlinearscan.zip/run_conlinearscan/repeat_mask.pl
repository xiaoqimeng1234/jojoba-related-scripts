#!/usr/bin/perl

##
# repeat_mask.pl
# This script masks all repeated anchors (>=20).
#
# Created by Li Zhe, 2005-01-27
#
# Modified by Li Zhe, 2005-12-10
#
# Modified by Li Zhe, 2005-12-23
#   . use Getopt::Std to handle cmd line arguments
#   . use Pod::Usage to generate online doc
#

use strict;
use warnings;

use Getopt::Std;
use Pod::Usage;

# get options
my %options;
getopts('n:h', \%options);
my $repeat_num = $options{'n'} || 20;
HELP_MESSAGE() if ($options{'h'});

my %id_table;
my @lines;

while (<>) {
  push @lines, $_;
  my ($id1, $id2) = (split /\s+/)[0,3];
  $id_table{$id1}++;
  $id_table{$id2}++;
}

foreach (@lines) {
  my ($id1, $id2) = (split /\s+/)[0,3];
  next if ($id1 eq $id2);
  next if ($id_table{$id1} >= $repeat_num || 
	   $id_table{$id2} >= $repeat_num);
  print $_;
}

sub HELP_MESSAGE {
  pod2usage(-exitval => 1,
	    -verbose => 2);
}

__END__

=head1 NAME

repeat_mask.pl - Masks repeat anchors use a very simple algorihm.

=head1 SYNOPSIS

B<repeat_mask.pl [options]>

=head1 DESCRIPTION

The program B<repeat_mask> reads pair files from standard input and
masks highly repeated anchors using a very simple algorithm. If an
anchor has pairs more than indicated number can be concidered as
highly repeated and masks it off from pair file. The results will be
write to standard output.

=head1 OPTIONS

=over 8

=item B<-n num>

Indicates the largest repeat number allowed. All anchors with pairs
more than the number will be masked off. If no number designated,
default is 20.

=item B<-h>

Show this message.

=back
