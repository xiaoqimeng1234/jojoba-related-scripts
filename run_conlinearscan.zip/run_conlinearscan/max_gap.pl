#!/usr/bin/perl -w

##
# max_gap.pl
#
# This script calculates maximum gap (param mg) which
# is used by ColinearScan program.
#
# Orignally designed by WangXY.
# This script is a modified version,
#
# Created by Li Zhe, 2005-01-30
#
# Modified by Li Zhe, 2005-12-10
#   Using Getopt::Long to process command line arguments.
#   Add some exception processes.
#
# Modified by Li Zhe, 2005-12-11
#   Using Pod::Usage to generate online doc.
#

use strict;
use warnings;

use Getopt::Long;
use Pod::Usage;

# our own little modules...
use SimpleFile;
use PairFile;

# processing cmd line arguments...
my @opt_lenfile;
my $opt_suffix;
my $opt_help = 0;
my $within_spec = 0;

GetOptions('help|?' => \$opt_help,
	   'lenfile=s' => \@opt_lenfile,
	   'suffix=s' => \$opt_suffix);
pod2usage(-exitval => 1, -verbose => 2) if $opt_help;
pod2usage(-msg => "Invalid arguments.",
	  -exitval => 2,
	  -verbose => 1)
  unless (scalar @opt_lenfile > 0 && $opt_suffix);
if (scalar @opt_lenfile == 1) {
  push @opt_lenfile, $opt_lenfile[0];
  $within_spec = 1;
}
@opt_lenfile = split(/,/, join(',', @opt_lenfile));

# open chromosome length file;
my @chr_lens;

foreach my $len_file (@opt_lenfile) {
  my $chr_len;

  eval {
    $chr_len = SimpleFile->new(-filename => $len_file);
  };
  if ($@) {
    print STDERR "An error occured when try to open chrosome length file \"$len_file\":\n$@\n";
    exit -1;
  }

  push @chr_lens, $chr_len;
}


# get list of file names of purged pairs
my @purged_files = glob "*." . $opt_suffix;

my $gaplensum1 = 0;
my $gaplensum2 = 0;
my $count = 0;

# check purged files exist
if (scalar @purged_files < 1) {
  print STDERR "No pair file found.\n";
  exit(-4);
}

# iterate through all pair files, and calculate mg for each file
foreach (@purged_files) {
  my $purged_file;

  eval {
    $purged_file= PairFile->new(-filename => $_);
  };
  if ($@) {
    print STDERR "An error occured when try to open pair file \"$_\":\n$@\n";
    exit -2;
  }

  my $chr1 = $purged_file->first_chr;
  my $chr2 = $purged_file->second_chr;

  next if ($purged_file->pair_num < 4); # if no pair exists, just ignore the file

  # using the simplified fomula from WangXY
  my ($gaplen1, $gaplen2);
  eval {
    $gaplen1 = $chr_lens[0]->get($chr1) * (0.01) ** (1/6) / perm($purged_file->pair_num, 4) ** (1/6);
    $gaplen2 = $chr_lens[1]->get($chr2) * (0.01) ** (1/6) / perm($purged_file->pair_num, 4) ** (1/6);
  };
  if ($@) {
    print STDERR "An error occured when try to calculate gap length:\n$@\n";
    exit -3;
  }

  # >>> for DEBUG
#  print "+++> gaplen1 = $gaplen1, gaplen2 = $gaplen2\n";

  $count++;

  $gaplensum1 += $gaplen1 * 1.2;
  $gaplensum2 += $gaplen2 * 1.2;
}

# average mg's get from pair files
my $avg_gap1 = $gaplensum1 / $count;
my $avg_gap2 = $gaplensum2 / $count;

$avg_gap1 = sprintf("%.0f", $avg_gap1/1000 + 0.5) * 1000 if ($avg_gap1 > 5000);
$avg_gap2 = sprintf("%.0f", $avg_gap2/1000 + 0.5) * 1000 if ($avg_gap2 > 5000);

#print "average gap length of 1st. species = ", $avg_gap1, "\n";
#print "average gap length of 2nd. species = ", $avg_gap2, "\n";
if ($within_spec) {
  my $avg_gap = ($avg_gap1 + $avg_gap2) / 2;
  print "$avg_gap\n";
}
else {
  print "$avg_gap1\t$avg_gap2\n";
}

# calculate permutation number
sub perm {
  my ($pnum, $r) = @_;
  my $p = 1;
  for(my $i = 1; $i < $r; $i++) {
    $p *= ($pnum - $i + 1);
  }
  return $p;
}

__END__

=head1 NAME

max_gap.pl - calculate mg (maximum gap) value from pair files

=head1 SYNOPSIS

max_gap.pl --lenfile chrlenfile [--lenfile chrlenfile] --suffix pairfile_suffix

=head1 ARGUMENTS

=over

=item --lenfile chrlenfile

Indicates chromosome length files. There should be 2 chromosome length
files, if two speciecies involved in the analysis, and the order of
chromosome length files should be correspondings to the pairs in the
pair files. If analysing within one species one chromosome length file
is enough.

=item --suffix pairfile_suffix

Indicates suffix of pair files. The script will open all file with
the suffix and try to read pairs from them.

=back

=cut
