#!/usr/bin/perl

########################################
# getpairs.pl
# This script is used to extract gene
# pairs from blast output file.
# We use max score of HSPs (>=100) as
# threshold to justify those pairs.
# This script just read from STDIN and
# write to STDOUT.
#
# Created by LiZhe, 10/31/04
#
# Modified by LiZhe, 2004-11-02
#   1. use standard FASTA format come 
#      from get_pair.pl
# Modified by LiZhe, 2005-12-22
#   1. use Getopt::Long to handle cmd
#      line paramters
#   2. use Pod::Usage to generate 
#      online documentation
########################################

use strict;
use warnings;

use Getopt::Long;
use Pod::Usage;

use Bio::SearchIO;

=head1 NAME

get_pairs.pl - extract pairs from BLAST results which statisfy cut-off(score or e-value)

=head1 SYNOPSIS

B<get_pairs.pl --score cut-off>

B<get_pairs.pl --evalue cut-off>

=head DESCRIPTION

The program B<get_pairs.pl> reads BLAST results from standard input
and extracts pairs statisfying cut-off rule (above inidicated score or
below designated e-value). Then write all pairs to standard output.

=head1 ARGUMENTS

=over 8

=item B<--score cut-off>

Indicates score value used as cut-off to extract pairs. All results
containing a HSP with >= B<cut-off> will be extracted and the query
and the hit will be outputed as a pair.

=item B<--evalue cut-off>

Indicates e-value used as cut-off. A pair will be extracted when there
is a HSP with e-value <= B<cut-off>.

=back

=cut

my $blast_in;

# processing cmd line arguments
my $opt_help;
my $opt_score;
my $opt_evalue;

GetOptions('help|?'   => \$opt_help,
	   'score=i'  => \$opt_score,
	   'evalue=f' => \$opt_evalue);

pod2usage(-exitval => 1, -verbose => 2) if $opt_help;

pod2usage(-msg => "No cut-off (score/e-value) provided.",
	  -exitval => 2,
	  -verbose => 1)
  unless ($opt_score || $opt_evalue);

pod2udage(-msg => "Only one cut-off rule should be set.",
	  -exitval => 2,
	  -verbose => 1)
  if ($opt_score && $opt_evalue);

# open STDIN to read blast results
eval {
  $blast_in = Bio::SearchIO->new( -format => "blast",
				  -fh => \*STDIN );
};
if ( $@ ) {
  print STDERR "ERROR: Cannot open STDIN to read.\n\n$@\n";
  exit(1);
}

# parse the BLAST file
eval {

  # iterate through all results
  while ( my $result = $blast_in->next_result ) {

    # get query name and description
    my $queryName = $result->query_name;
    my $queryDesc = $result->query_description;

    # iterate through all hits of result
    while ( my $hit = $result->next_hit ) {

      # get hit name and description
      my $hitName = $hit->name;
      my $hitDesc = $hit->description;

#      print STDERR "Query Name: $queryName, Query Desc: $queryDesc, Hit Name: $hitName\n";

      # iterator through all HSP of hit
      while ( my $hsp = $hit->next_hsp ) {

	# use booleam expression short-circuit here....
	if ( ($opt_score and $hsp->score >= $opt_score) or
	     ($opt_evalue and $hsp->evalue >= $opt_evalue) ) {
	  # parse query name
	  my ( $query_dir, $query_pos ) = parse_desc( $queryDesc );
	  # parse hit name
	  my ( $hit_dir, $hit_pos ) = parse_desc( $hitDesc );
	  # output the pair
	  print STDOUT "$queryName $query_dir $query_pos $hitName $hit_dir $hit_pos\n";

	  # get out of loop
	  last;
	}
      }
    }
  }
};
if ( $@ ) {
  print STDERR "ERROR: An error occured while parse BLAST file.\n\n$@\n";
  exit(-1);
}


##
# parse_desc: function used to parse 
# the description of queris and hits of
# BLAST results
#
sub parse_desc {
  my ( $name ) = @_;
  my ( $direction, $gene_start );
  if ( $name =~ /([\+\-]?\d+)\|(\d+)/ ) {
    $direction = $1;
    $gene_start = $2;
  }
  else {
    die "Cannot recoganize name: $name";
  }
  return ( $direction, $gene_start );
}

__END__
