### input files
#   blastout between genes
#   chromosome length files: 1 for within genome blast, 2 for between genome blast
#   gene positions in bp:    1 for within genome blast, 2 for between genome blast
###
print "\n\n Usage :  perl this_script blastm8 chrolenfile1 chrolenfile2 geneposfile1 geneposfile2\n\n";

print "some parameters may need to be changed int this_script\n\n";

use strict;
use GD;
use GD::Image;
use GD::Text::Align;

###### parameters for significant hits, for filtering repeats
my $EVALUE = 1e-5;
my $SCORE  = 100;
my $HITNUM = 5;
my $REPNUM = 20;

###### parameters for input files
my $blastout = "$ARGV[0]_$ARGV[1].blast.new"; #input blast result files
                         #gene name format: ssxx..xGoo..o
                         #                  ss -- two letter coding for species
                         #                  xx..x -- chromosome number, sometimes very large
                         #                  oo..o -- gene cardinal number on a chromosome, generally, but may vary
my $chrolenfile1 = "$ARGV[0].lens";  ### file format: chromosome#	length
my $chrolenfile2 = "$ARGV[1].lens";
my $geneposfile1 = "$ARGV[0].new.gff";### file format: gene	position
my $geneposfile2 = "$ARGV[1].new.gff";

###### parameters of the figures
my $cell_width = 2;
my $cell_height= $cell_width;
my $frame_width = 2000;#�߿����2000
my $frame_height= 2000;#�߿�߶�2000

my $left_curb = 200;#��߿հ�200
my $top_curb  = 200;#�ϱ߿հ�200

my $figure_file = "$ARGV[0]_$ARGV[1].dotplot.png";#������ļ���
open(FIG, ">".$figure_file) or die "cannot open $figure_file due to $!\n";

###### 


my $is_within_species = 0;
if($chrolenfile1 eq $chrolenfile2 && $geneposfile1 eq $geneposfile2)#�������1������2��ͬһ��
{
   $is_within_species = 1;#��ô....����1
}
#print $is_within_species."\n";
my @chrlen1;
my @chrlen2;
my %genepos1;
my %genepos2;
my %geneorder1;
my %geneorder2;
my %order2sca;
my %sca2order;
my $testfile = "test.txt";
open (TS,">",$testfile) or die "can not open testfile $testfile due to $!.\n";

my ($genome1_length_bp, $genome2_length_bp) = (0, 0);

if($is_within_species eq 0)#������1������2����ͬһ��
{
	 @chrlen1 = input_chro_len1($chrolenfile1);#����1lens
   %genepos1 =input_gene_pos1($geneposfile1);#����1ʵ��λ��
   %geneorder1 = input_gene_order1($geneposfile1);#����1order
   
   @chrlen2 = input_chro_len2($chrolenfile2);#����2lens
   %genepos2 =input_gene_pos2($geneposfile2);#����2ʵ��λ��
   %geneorder2 = input_gene_order2($geneposfile2);#����2order
   
   $genome1_length_bp = sum_chr_len(@chrlen1);   
   $genome2_length_bp = sum_chr_len(@chrlen2);
	
}
else#������������Ϊͬһ����
{
   @chrlen1 = input_chro_len1($chrolenfile1);#����1lens
   %genepos1 =input_gene_pos1($geneposfile1);#����1ʵ��λ��
   %geneorder1 = input_gene_order1($geneposfile1);#����1order

   @chrlen2 = @chrlen1;#����2lens������1lensһ��
   %genepos2 = %genepos1;#����2ʵ��λ�ú�����1ʵ��λ��һ��
   %geneorder2=%geneorder1;#����2order������1orderһ��

   $genome1_length_bp = sum_chr_len(@chrlen1);
   $genome2_length_bp = $genome1_length_bp;
}

my $chrno1 = $#chrlen1 +1;
my $chrno2 = $#chrlen2 +1;
print "$chrno2\n";
#print $genome1_length_bp."\n\n\n\n\n\n\n\n";
###### calculate scale ratio �������
my $scale_ratio1 = $genome1_length_bp/$frame_width; ## horizontal
my $scale_ratio2 = $genome2_length_bp/$frame_height;## vertical
print $genome1_length_bp." ".$frame_width." ".$scale_ratio1."\n";
print $genome2_length_bp." ".$frame_height." ".$scale_ratio2."\n";

###### draw the frame and the saprating lines corresponding to chromosome borders ������Ⱦɫ��߽����Ӧ�Ŀ�ܺ�������
my $img = GD::Image -> new($frame_width + 2*$left_curb, $frame_height + 2*$top_curb);#�߿����+��������հף������ƣ����߿�߶�+�����Ķ��հף������ƣ�
my $white = $img -> colorAllocate(255, 255, 255);
$img -> transparent($white);
$img -> interlaced('true');

my $black = $img->colorAllocate(0,0,0);###��ɫ��0��0��0���ǻ�ͼ�������ɫ������Ϊ0��0��0֮����Ǻ�ɫ
my $red = $img->colorAllocate(255,0,0);###��ɫ
my $blue = $img->colorAllocate(0,0,255);####��ɫ
my $gold =$img->colorAllocate(255,204,0);####��ɫ
my $green =$img->colorAllocate(51,153,102);####����ɫ
my $fenhong =$img->colorAllocate(255,0,255);####�ۺ�ɫ
my $zise =$img->colorAllocate(128,0,128);####��ɫ
my $qianlan =$img->colorAllocate(51,102,255);####ǳ��ɫ
my $darkgrey = $img->colorAllocate(192,192,192);###���ɫ

my $darkgoldenrod = $img->colorAllocate(184,134,11);###�����ٻ�
my $olive = $img->colorAllocate(128,128,0);###���ɫ
my $skyblue = $img->colorAllocate(30,144,255);###����

$img -> rectangle($left_curb, $top_curb, $frame_width + $left_curb, $frame_height + $top_curb,$black);#2*$top_curb������ 2*$left_curb������ 2*$frame_width + $left_curb�����쳤  2*$frame_height + $top_curb�����쳤 ��߿���ϱ߿�


#$img -> string(gdGiantFont, 70, 40, "Oryza sativa vs. Oryza sativa", $black);#############################################################
#gdGiantFont
#stringUp;nishizhenxuanzhuan90.
################
#my $fontScale = 30;
#my $align = GD::Text::Align->new($img);
#($img, valign => 'center',  halign => 'center',color =>$black);
#$align->set_font('arial', $fontScale*10000000000000);
#$align->set_valign('top');
#$align->set_halign('center');
#$align->set_text('wang');
#$align->draw(500,500,0);
#################
#################
my $fontScale = 60;#Ⱦɫ��ź��������������С
my $testContent = "";

my $align = GD::Text::Align->new($img, valign => 'center',  halign => 'center',color =>$black);
$align->set_font('C:\WINDOWS\Fonts\timesbi.ttf', $fontScale);
$align->set_valign('bottom');
$align->set_halign('center');
$align->set_text("$ARGV[0]");
$align->draw(1200,100,0);##########��һ�����ͣ�1100,100,0��������������������������һ��

$align->set_text("$ARGV[1]");
$align->draw(100,1200,1.57 );##########��һ�����ͣ�95,1100,-4.7163��������������������������һ��
#################
my @chro_pos1 = ();
my @chro_pos2 = ();

my $accumulated_length = 0;
for(my $j=1;$j<=100;$j++)
{
#$img -> line(200+20*$j, 200, 200+20*$j, 2200, $darkgrey);
#$img -> line($posx1-2*$length/5, $posy1, $posx1-2*$length/5, $frame_height+$top_curb, $green);
#$img -> line($posx1-$length/5*3, $posy1, $posx1-$length/5*3, $frame_height + $top_curb, $green);
#$img -> line($posx1-$length/5*4, $posy1, $posx1-$length/5*4, $frame_height + $top_curb, $green);
}
for(my $j=1;$j<=100;$j++)
{
#$img -> line(200, 200+20*$j, 2200, 200+20*$j, $darkgrey);
#$img -> line($posx1, $posy1-$length/5*3, $posx2, $posy2-$length/5*3, $green);
#$img -> line($posx1, $posy1-$length/5*2, $posx2, $posy2-$length/5*2, $green);
#$img -> line($posx1, $posy1-$length/5, $posx2, $posy2-$length/5, $green);
}
for(my $i=0; $i<=$#chrlen1; $i++)
{
   $accumulated_length += $chrlen1[$i];#accumulated_length = accumulated_length + $chrlen1�����۵ĳ��ȵ������еļ��ϸ�Ҫ���ϵģ�
      my $length = int($chrlen1[$i]/$scale_ratio1);#length���ڸ��Ե�Ⱦɫ�峤���ϱ�����Ȼ��ȡ��
   my $posx1 = $left_curb + int($accumulated_length/$scale_ratio1);#posx1������հ׼��ϣ����۵ĳ��ȱ��ϱ��� ȡ����
   $chro_pos1[$i] = $posx1;#chro_pos1����posx1
   my $posy1 = $top_curb;#posy1���ڶ��հ�
   my $posx2 = $posx1;#posx2����posx1
   my $posy2 = $top_curb + $frame_height;#posy2���ڶ��հ׼��ϱ߿�߶�
my $chro = $i+1;#Ⱦɫ������������

print $posx1." ".$posy1." ".$posx2." ".$posy2."\n";
   $img -> line($posx1, $posy1, $posx2, $posy2, $black);









   $align->set_font('C:\WINDOWS\Fonts\TIMESBD.TTF', $fontScale*0.5);#TIMESBD.TTF �ĵ���Ⱦɫ�����ֵ��ֺŴ�С
   $align->set_text("".$chro);
$align->draw($posx1-int($length/2),170,1);#########��һ������$length/2)+30,170,1.0һ��
	#$align->set_text("|",$fontScale*0.01);

# $img -> line($posx1, $posy1, $posx2, $posy1-int($length/5*4)+20, $red);



#$align->draw($posx1-int($length/5),200,0);
#$align->draw($posx1,200,0);
#$align->draw($posx1-int($length/5*2),200,0);
#$align->draw($posx1-int($length/5*3),200,0);
#$align->draw($posx1-int($length/5*4),200,0);
#$align->draw(200,200,0);
#$align->draw(2200,200,0);
################################################################################$img -> rectangle($posx1-int($length/5),$posx2-int($length/5), $posy1-int($length/5)+20,$posy2-int($length/5)+20, $green);

# $align->draw(195,$posy1+20,0);
# $align->draw(195,$posy1-int($length/5*4)+20,0);
# $align->draw(195,$posy1-int($length/5*2)+20,0);
# $align->draw(195,$posy1-int($length/5)+20,0);
#my $img = GD::Image -> new($posx1-int($posx1-int($length/5), $posy1-int($length/5)+20);
	#$img -> string(gdGiantFont, $posx1-int($length/2)-20,170, "Ob".$chro, $black);
}

$accumulated_length = 0;
for(my $i=0; $i<=$#chrlen2; $i++)
{
   $accumulated_length += $chrlen2[$i];#accumulated_length = accumulated_length + chrlen2[$i]
      my $length = int($chrlen2[$i]/$scale_ratio2);#length = Ⱦɫ�峤�ȱ��ϱ���
   my $posy1 = $top_curb + int($accumulated_length/$scale_ratio2);
   $chro_pos2[$i] = $posy1;
   my $posx1 = $left_curb;
   my $posy2 = $posy1;
   my $posx2 = $left_curb + $frame_width;
my $chro2 = $i+1;

#print "\n\n\n\n\n$posx1\t$posy1\t$posx2\t$posy2\n\n\n\n";
   $img -> line($posx1, $posy1, $posx2, $posy2, $black);#######




# $align->draw(195,$posy1+20,0);
# $align->draw(195,$posy1-int($length/5*4)+20,0);
# $align->draw(195,$posy1-int($length/5*2)+20,0);
# $align->draw(195,$posy1-int($length/5)+20,0);
#my $img = GD::Image -> new($posx1-int($posx1-int($length/5), $posy1-int($length/5)+20);



   #$img -> string(gdGiantFont,150, $posy1-int($length/2)-10, "Ob".$chro2, $black);
   $align->set_text("".$chro2);
   $align->draw(150,$posy1-int($length/2)+20,0);####��һ������$length/2)+30,0һ��
}

###### input blast results to get gene pairs and gene repetive numbers.
my @genepair = ();
my %genenum1 = ();
my %genenum2 = ();
my $testfile = "test.txt";
open (TS,">",$testfile) or die "can not open testfile $testfile due to $!.\n";
my $geneidfile ="geneid.txt";
open (GI,">",$geneidfile) or die "can not open geneidfile $geneidfile due to $!.\n";
 my $genepairfile ="genepair.txt";
 open (GPA,">".$genepairfile) or die "can not open genepairfile $genepairfile due to $!.\n";

input_blastout($blastout);

###### filter repetive genes and draw a figure
for(my $i=0; $i<=$#genepair; $i++)
{
   
   my @arr = split(/\s/, $genepair[$i]);

   #### filter repeats
   if($is_within_species eq 0)
   {
      if($genenum1{$arr[0]} > $REPNUM){next;}
      if($genenum2{$arr[1]} > $REPNUM){next;}
   }
   else
   {
      if($genenum1{$arr[0]} > $REPNUM){next;}
      if($genenum2{$arr[1]} > $REPNUM){next;}
      if($genenum2{$arr[0]} > $REPNUM){next;}
      if($genenum1{$arr[1]} > $REPNUM){next;}
   }
   
   #### print further process
   print TS$arr[0]." ".$genepos1{$arr[0]}." ".$geneorder1{$arr[0]}." ".$arr[1]." ".$genepos2{$arr[1]}." ".$geneorder2{$arr[1]}."\t".$arr[2]."\n";
   #######best dot
if($arr[2] eq "1"){
   my @id1 = split(/[gG]/, $arr[0]);
   my $chr1 = $id1[0];
   $chr1 =~ s/^\D+//;
   $chr1 =~ s/^0+//;

   my @id2 = split(/[gG]/, $arr[1]);
   my $chr2 = $id2[0];
   $chr2 =~ s/^\D+//;
   $chr2 =~ s/^0+//;
print GI$chr1."\t".$chr2."\n";
   my ($posx, $posy);
   if($chr1 eq 1)
   {
      $posx = $left_curb + $genepos1{$arr[0]}/$scale_ratio1;
   }
   else
   {
      $posx = $chro_pos1[$chr1-2] + $genepos1{$arr[0]}/$scale_ratio1;
   }

   if($chr2 eq 1)
   {
      $posy = $top_curb + $genepos2{$arr[1]}/$scale_ratio2;
   }
   else
   #if($chr2 eq 3)
   {
      $posy = $chro_pos2[$chr2-2] + $genepos2{$arr[1]}/$scale_ratio2;
   }
   
   print GPA ("genepair:  $posx $posy\t|\t");
   #print GPA ("chr1 $chr1 sca $chr2\n");
   print GPA ("chr1 $arr[0] sca $arr[1]\n");
   #$img -> setPixel($posx, $posy, $blue);
   $img -> filledRectangle($posx, $posy, $posx+1, $posy+1, $red);}########��ɫʵ�ľ���
##########secondary dot
elsif($arr[2] eq "2"){
   my @id1 = split(/[gG]/, $arr[0]);
   my $chr1 = $id1[0];
   $chr1 =~ s/^\D+//;
   $chr1 =~ s/^0+//;

   my @id2 = split(/[gG]/, $arr[1]);
   my $chr2 = $id2[0];
   $chr2 =~ s/^\D+//;
   $chr2 =~ s/^0+//;
print GI$chr1."\t".$chr2."\n";
   my ($posx, $posy);
   if($chr1 eq 1)
   {
      $posx = $left_curb + $genepos1{$arr[0]}/$scale_ratio1;
   }
   else
   {
      $posx = $chro_pos1[$chr1-2] + $genepos1{$arr[0]}/$scale_ratio1;
   }

   if($chr2 eq 1)
   {
      $posy = $top_curb + $genepos2{$arr[1]}/$scale_ratio2;
   }
   else
   #if($chr2 eq 3)
   {
      $posy = $chro_pos2[$chr2-2] + $genepos2{$arr[1]}/$scale_ratio2;
   }
   
   print GPA ("genepair:  $posx $posy\t|\t");
   #print GPA ("chr1 $chr1 sca $chr2\n");
   print GPA ("chr1 $arr[0] sca $arr[1]\n");
   #$img -> setPixel($posx, $posy, $blue);
   $img -> filledRectangle($posx, $posy, $posx+0.5, $posy+0.5, $blue);}#########��ɫʵ�ľ���
###########other hit dot
else{
   my @id1 = split(/[gG]/, $arr[0]);
   my $chr1 = $id1[0];
   $chr1 =~ s/^\D+//;
   $chr1 =~ s/^0+//;

   my @id2 = split(/[gG]/, $arr[1]);
   my $chr2 = $id2[0];
   $chr2 =~ s/^\D+//;
   $chr2 =~ s/^0+//;
print GI$chr1."\t".$chr2."\n";
   my ($posx, $posy);
   if($chr1 eq 1)
   {
      $posx = $left_curb + $genepos1{$arr[0]}/$scale_ratio1;
   }
   else
   {
      $posx = $chro_pos1[$chr1-2] + $genepos1{$arr[0]}/$scale_ratio1;
   }

   if($chr2 eq 1)
   {
      $posy = $top_curb + $genepos2{$arr[1]}/$scale_ratio2;
   }
   else
   #if($chr2 eq 3)
   {
      $posy = $chro_pos2[$chr2-2] + $genepos2{$arr[1]}/$scale_ratio2;
   }
   
   print GPA ("genepair:  $posx $posy\t|\t");
   #print GPA ("chr1 $chr1 sca $chr2\n");
   print GPA ("chr1 $arr[0] sca $arr[1]\n");
   #$img -> setPixel($posx, $posy, $blue);
   $img -> filledRectangle($posx, $posy, $posx+1, $posy+1, $darkgrey);}########��ɫʵ�ľ���

}
binmode FIG;
print FIG$img -> png;

close($figure_file);

sub input_blastout()
{
#my @array = split(/\./,$_[0]);
#my $species1 = $array[0];
#my $species2 = $array[2];

open(IN, $blastout) or die "cannnot open the input file $blastout due to $!.\n";

my $subjctnum = 0;
my $query = "";
my $lastquery = "";
my $lastsubjct= "";
my $hitnum = 1;
my $pairnum = 0;

while(<IN>)
{
   my @array = split(/\s+/, $_);
   
   if($array[11] < $SCORE){next;} # the blast score for the longest hit segment
   if($array[10] > $EVALUE){next;} # the blast e-value

   $array[0] =~ s/g/G/;
   $array[1] =~ s/g/G/;

   if($array[0] eq $lastquery && $array[1] eq $lastsubjct){next;} # subhit regions were overlooked
   if($array[0] eq $array[1]){next;} # the same genes hit were overlooked
   
   my $genename1 = $array[0];
   my @genename1 = split(/G/, $genename1);
   $genename1[0] =~ s/^\D+//;
   $genename1[0] =~ s/^0+//g;
   my $chro1 = $genename1[0];

   my $genename2 = $array[1];
   my @genename2 = split(/G/, $genename2);
   $genename2[0] =~ s/^\D+//;
   $genename2[0] =~ s/^0+//;
   my $chro2 = $genename2[0];

      if($array[0] eq $lastquery)
   {
      if($hitnum >= $HITNUM){next;}
      $hitnum ++;
   }
   else{$hitnum = 1;}

   if($genenum1{$genename1} > 1){$genenum1{$genename1} ++;} else {$genenum1{$genename1} = 1;}
   if($genenum2{$genename2} > 1){$genenum2{$genename2} ++;} else {$genenum2{$genename2} = 1;}
   
   $genepair[$pairnum] = $array[0]." ".$array[1]." ".$hitnum;
   $pairnum++;

   $lastquery = $array[0];
   $lastsubjct= $array[1];
}

close($blastout);
}

sub input_chro_len1()
{
   my $chrolenfile1 = $_[0];#����ĵ�һ��Ԫ�ظ���$chrolenfile
   print "inputing ".$chrolenfile1." ....\n";

   open(CL1, $chrolenfile1) or die "cannot open $chrolenfile1 due to $!\n";
   my @chrolen1 = ();
   my $order = 1;
   while(<CL1>)
   {
      my $line = $_;
      $line =~ s/[\n\r]//g;
      my @arr = split(/\s+/, $line);

      $arr[0] =~ s/^\D+//;
      
      $arr[0] =~ s/^0+//;
      $order2sca{$order} = $arr[0]; 
      $sca2order{$arr[0]} = $order;
      $chrolen1[$arr[0]-1] = $arr[1];
      print $order." ".$arr[0]." ".$arr[1]."\n";
      $order ++;
   }
   return @chrolen1;
}

sub input_chro_len2()
{
   my $chrolenfile2 = $_[0];
   print "inputing ".$chrolenfile2." ....\n";

   open(CL2, $chrolenfile2) or die "cannot open $chrolenfile2 due to $!\n";
   my @chrolen2 = ();
   my $order = 1;
   while(<CL2>)
   {
      my $line = $_;
      $line =~ s/[\n\r]//g;
      my @arr = split(/\s+/, $line);

      $arr[0] =~ s/^\D+//;
      $order2sca{$order} = $arr[0];
      $sca2order{$arr[0]} = $order;

      $chrolen2[$arr[0]-1] = $arr[1];
      print $order." ".$arr[0]." ".$arr[1]."\n";
      $order ++;
   }
   return @chrolen2;
}

sub input_gene_pos1()
{
   my $geneposfile1 = $_[0];
   print "inputing ".$geneposfile1." ....\n";

   open(GP1, $geneposfile1) or die "cannot open $geneposfile1 due to $!\n";
   my %genepos1 = {};
   
   my $posfile1 = "posfile1.txt";
   open (PF1,">".$posfile1) or die "can not open pos file $posfile1 due to $!.\n";
   while(<GP1>)
   {
      my $line = $_;
      $line =~ s/[\n\r]//g;
      my @arr = split(/\s+/, $line);
      
      $arr[1] =~ s/g/G/;
      $genepos1{$arr[1]} = $arr[5];
#print $arr[0]." ".$arr[1]."\n";
print PF1 ("$arr[1]\t$arr[2]\n");
   }
   return(%genepos1);
}

sub input_gene_pos2()
{
   my $geneposfile2 = $_[0];
   print "inputing ".$geneposfile2." ....\n";

   open(GP2, $geneposfile2) or die "cannot open $geneposfile2 due to $!\n";
   my %genepos2 = {};
   
   my $posfile2 = "posfile2.txt";
   open (PF2,">".$posfile2) or die "can not open pos file $posfile2 due to $!.\n";
   while(<GP2>)
   {
      my $line = $_;
      $line =~ s/[\n\r]//g;
      my @arr = split(/\s+/, $line);
      
      $arr[1] =~ s/g/G/;
      $genepos2{$arr[1]} = $arr[5];
#print $arr[0]." ".$arr[1]."\n";
print PF2 ("$arr[1]\t$arr[2]\n");

   }
   return(%genepos2);
}

sub input_gene_order1()
{
   my $geneposfile1 = $_[0];
   print "inputing ".$geneposfile1." ....\n";   

   open(GP1, $geneposfile1) or die "cannot open $geneposfile1 due to $!\n";
   my %geneorder1 = {};
  
   my $genenum = 0; 
   my $lastchro = "";
   my $lastpos  = "";
   my $lastorder= "";
my $orderfile = "order1.txt";
open (OR,">".$orderfile) or die "can not open order file $orderfile due to $!.\n";
   while(<GP1>)
   {
      my $line = $_;
      $line =~ s/[\n\r]//g;
      my @arr = split(/\s+/, $line);
      
      my @id = split(/[Gg]/, $arr[0]);
      $id[0] =~ s/^\D+//;
      $id[0] =~ s/^0+//;
      #$id[1] =~ s/^0+//;#print $id[1]."\n";

      if($lastchro eq $id[0])
      {
         $genenum ++;
         #if($lastpos > $arr[1] || $lastorder > $id[1] ){print "wrong order !!!\n"; exit(0);}
         #$arr[0] =~ s/g/G/;
         $geneorder1{$arr[0]} = $genenum;      
      }
      else
      {
         $genenum = 1;
         $geneorder1{$arr[0]} = $genenum;
      }
      print OR"genenum .. ".$arr[0]." ".$genenum."\n";

      $lastchro = $id[0];
   }
   return(%geneorder1);
}

sub input_gene_order2()
{
   my $geneposfile2 = $_[0];
   print "inputing ".$geneposfile2." ....\n";   

   open(GP2, $geneposfile2) or die "cannot open $geneposfile2 due to $!\n";
   my %geneorder2 = {};
  
   my $genenum = 0; 
   my $lastchro = "";
   my $lastpos  = "";
   my $lastorder= "";
my $orderfile = "order2.txt";
open (OR,">".$orderfile) or die "can not open order file $orderfile due to $!.\n";
   while(<GP2>)
   {
      my $line = $_;
      $line =~ s/[\n\r]//g;
      my @arr = split(/\s+/, $line);
      
      #my @id = split(/_/, $arr[0]);####$id[1]�ǵڼ���scaffold
      #$id[0] =~ s/^\D+//;
      #$id[0] =~ s/^0+//;
      #$id[1] =~ s/^0+//;#print $id[1]."\n";
      my @id = split(/[Gg]/, $arr[0]);
      $id[0] =~ s/^\D+//;
      $id[0] =~ s/^0+//;

      if($lastchro eq $id[0])
      {
         $genenum ++;
         #if($lastpos > $arr[1] || $lastorder > $id[1] ){print "wrong order !!!\n"; exit(0);}
         #$arr[0] =~ s/g/G/;
         $geneorder2{$arr[0]} = $genenum;         
     }
      else
      {
         $genenum = 1;
         $geneorder2{$arr[0]} = $genenum;
      }
      print OR"genenum .. ".$arr[0]." ".$arr[1]." ".$genenum."\n";

      $lastchro = $id[0];
   }
   return(%geneorder2);
}


sub sum_chr_len()
{
   my @chrlen = @_;
   my $sumlen = $chrlen[0];
   for(my $i=1; $i<=$#chrlen; $i++)
   {$sumlen = $sumlen + $chrlen[$i];
   }
   return $sumlen;
}
