use strict;
#use warnings;

my @file = glob "*.blast";
for (my $i=0;$i<=$#file;$i++)
{
	open (IN, "$file[$i]") or die;
	#my @name=split(/\./,$file[$i]);
    open (OUT, ">$file[$i].order") or die;

my $old;
my $num;
while(<IN>)
{
	chomp;
	if ($_=~/Scaffold/) {next;}
	my @arr=split(/\s+/,$_);

	if ($old eq $arr[0])
		{	$num++;}
	if ($old ne $arr[0]){$num=1;}

	print OUT "$arr[0]\t$arr[1]\t$num\n";
	$old=$arr[0];
	}
}