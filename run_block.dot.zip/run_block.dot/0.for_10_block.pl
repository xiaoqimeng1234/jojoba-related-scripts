use strict;

my @file = glob "*.block.rr.txt";
for (my $i=0;$i<=$#file;$i++)
{
	my @name=split(/\./,$file[$i]);
	open (IN, "$name[0].block.rr.txt") or die;
	open (OUT, ">$name[0].10.block.txt") or die;

	my $lens=0;
	while (<IN>)
	{
	    my @array=split(/\s+/,$_);
	    if($_=~/length/){$lens=$array[4];}
	    if($lens < 8 ){next;}
	    print OUT "$array[0] $array[1] $array[2] $array[3] $array[4]\n";

	}

}