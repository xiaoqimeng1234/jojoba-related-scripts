#!/usr/bin/env python
# -*- coding: utf-8 -*-

#author: sunpengchuan 
#email:  sunpengchuan@gmail.com
#date:   20188-6-2

import sys
import re
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import matplotlib.patches as mpatches


class dotplot():
    def __init__(self,config):
        self.config=config
        for k in self.config.index:
            setattr(self,str(k),self.config.loc[k,1])

    def plot_chr1(self,lens, gl, gl2, step, mark, name):###竖物种
        gl_start, n, start_x = 0.95, 0, 0.05   ##控制竖线
        mark_y = 0.03###纵坐标染色体号+物种拉丁文位置（竖）
        align = dict(family='Arial', style='normal', horizontalalignment="center", verticalalignment="center")###染色体号
        align1 = dict(family='Arial', style='italic', horizontalalignment="center", verticalalignment="center")###物种拉丁文
        for k in lens.index:
            n += float(lens.at[k, 1])
            mark_new = str(mark) + str(k)
            x = gl_start - float(n) * step
            mark_x = x + 0.5 * float(lens.at[k, 1]) * step
            plt.plot([start_x, start_x + gl2], [x, x], linestyle='-', color='gray', linewidth=0.5)##ºáÏß¿í¶È
            plt.text(mark_y, mark_x, mark_new, color='black', fontsize=5, rotation=90, weight='semibold', **align)####染色体号
        plt.plot([start_x, start_x + gl2], [gl_start, gl_start], linestyle='-', color='gray', linewidth=0.5)
        plt.text(mark_y-0.04, 0.5 * (2 * gl_start - gl), name, color='black', fontsize=7, rotation=90,
                 weight='semibold', **align1)### 物种拉丁文，mark_y-0.04控制纵坐标左右移动

    def plot_chr2(self,lens, gl, gl2, step, mark, name):
        gl_start, n, start_x = 0.05, 0, 0.95
        mark_y = 0.96#横坐标物种拉丁文位置，0.96位于上部
        align = dict(family='Arial', style='normal', horizontalalignment="center", verticalalignment="center")
        align1 = dict(family='Arial', style='italic', horizontalalignment="center", verticalalignment="center")
        for k in lens.index:
            n += float(lens.at[k, 1])
            mark_new = str(mark) + str(k)
            x = gl_start + float(n) * step
            mark_x = x - 0.5 * float(lens.at[k, 1]) * step
            plt.plot([x, x], [start_x, start_x - gl2], linestyle='-', color='gray', linewidth=0.5)
            plt.text(mark_x, mark_y+0.005, mark_new, color='black',fontsize=5, rotation=0, weight='semibold', **align)####控制染色体号位置，mark_y+0
        plt.plot([gl_start, gl_start], [start_x, start_x - gl2], linestyle='-', color='gray', linewidth=0.5)
        plt.text(0.5 * (2 * gl_start + gl)+0.07, mark_y + 0.03, name, color='black', fontsize=7, rotation=0,
                 weight='semibold', **align1) ###### 横坐标物种拉丁文 ##mark—_y，控制拉丁文的位置上下，0.5 * (2 * gl_start + gl)+0.03基因名字左右移动。

    def gene_location(self,gff, lens, step):
        loc_gene, dict_chr, n = {}, {}, 0
        for i in lens.index:
            dict_chr[str(i)] = n
            n += float(lens.at[i, 1])
        for k in gff.index:
            if gff.loc[k, 0] not in dict_chr:
                continue
            loc = (float(dict_chr[gff.loc[k, 0]]) + float(gff.loc[k, 3])) * step
            loc_gene[gff.loc[k, 1]] = loc
        return loc_gene

    def plotfig(self):
        fig=plt.figure(figsize=(5, 5))######## 图片大小，长宽比例
        plt.axis('off')####坐标
        gff_1 = pd.read_csv(self.gff1, sep="\t", header=None)
        gff_2 = pd.read_csv(self.gff2, sep="\t", header=None)
        gff_1[0] = gff_1[0].astype('str')
        gff_2[0] = gff_2[0].astype('str')
        lens_1 = pd.read_csv(self.lens1, sep="\t", header=None, index_col=0)
        lens_2 = pd.read_csv(self.lens2, sep="\t", header=None, index_col=0)
        gl1, gl2 = 0.92, 0.92
        step1 = gl1 / float(lens_1[1].sum())
        step2 = gl2 / float(lens_2[1].sum())
        self.plot_chr1(lens_1, gl1, gl2, step1, '', self.genome1_name)
        self.plot_chr2(lens_2, gl1, gl2, step2, '', self.genome2_name)
        gene_loc_1 = self.gene_location(gff_1, lens_1, step1)
        gene_loc_2 = self.gene_location(gff_2, lens_2, step2)
        blast = pd.read_csv(self.blast, sep="\t", header=None)
        score, evalue, repnum = 200, 1e-5, 20
        #blast = blast[(blast[11] >= score) & (blast[10] < evalue) & (blast[1] != blast[0])]
        blast = blast[(blast[0].isin(gene_loc_1.keys())) & (blast[1].isin(gene_loc_2.keys()))]        
        colors = [ 'orangered','blue', 'gray']
        hitnum = 2
        x, y, colors = self.pair_positon(blast, gene_loc_1, gene_loc_2, hitnum, colors)        
        plt.scatter(x, y, s=0.3+0.3, c=colors, alpha=0.5, edgecolors=None, linewidths=0)# marker=(9, 3, 30))###x, y, s=0.2+0.4点的大小
        plt.subplots_adjust(left=0.09, right=1, top=0.98, bottom=0)#子图的区域
        plt.savefig(self.save_file+'.png',dpi=500)
        plt.savefig(self.save_file+'.pdf', dpi=500)

    def pair_positon(self,data, loc1, loc2, hitnum, colors):
        pos1, pos2, newcolor = [], [], []
        gl_start1, gl_start2 = 0.95, 0.05#######打点范围
        for index, k in data.iterrows():
            x = gl_start1 - loc1[k[0]]
            y = gl_start2 + loc2[k[1]]
            pos1.append(y)
            pos2.append(x)
            if k[2] == 1 or k[2] == 2:
                color = colors[0]
            elif k[2] == 3:
                color = colors[1]
            else:
                color = colors[2]
            newcolor.append(color)
        return pos1, pos2, newcolor

    def gene_location(self, gff, lens, step):
        loc_gene, dict_chr, n = {}, {}, 0
        for i in lens.index:
            dict_chr[str(i)] = n
            n += float(lens.at[i, 1])
        for k in gff.index:
            if gff.loc[k, 0] not in dict_chr:
                continue
            loc = (float(dict_chr[gff.loc[k, 0]]) + float(gff.loc[k, 3])) * step
            loc_gene[gff.loc[k, 1]] = loc
        return loc_gene

if __name__=="__main__":
    config=pd.read_csv(sys.argv[1],sep='\t',header=None,index_col=0)
    dotplot=dotplot(config)
    dotplot.plotfig()

