use strict;

my @file = glob "*.blast";
for (my $i=0;$i<=$#file;$i++)
{
	my @name=split(/\./,$file[$i]);
	open (IN1,"$name[0].blast.order")or die "due to $!\n";###blast.order
	open (IN2,"$name[0].blast.new")or die "due to $!\n";###collinearity.pair.txt
	open (OUT,">$name[0].collinearity.order")or die "due to $!\n";

	my %hash;
	while(<IN1>){
		chomp;
		my @a=split(/\t/,$_);
	#	if($a[0]==1){$a[0]="crimson";}
	#	if($a[0]==2){$a[0]="blue";}
	#	if($a[0]>2){$a[0]="grey";}
		my $genes="$a[0]\t$a[1]";
		$hash{$genes}=$a[2];
		#print "$genes\n";
	}
	close IN1;


	while(<IN2>){
		chomp;
		my @b=split(/\t/,$_);
		my $genes="$b[0]\t$b[1]";
		if(defined $hash{$genes}){
			print OUT "$genes\t$hash{$genes}\n";
		}
	}
}
