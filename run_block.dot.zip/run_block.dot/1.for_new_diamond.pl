use strict;

my @file = glob "*.blast";
for (my $i=0;$i<=$#file;$i++)
{
	my @name=split(/\./,$file[$i]);
	open(BLAST,"$name[0].blast") or die "cannot open blast due to $!.\n";
	open(BLOCK,"$name[0].10.block.txt") or die "cannot open block due to $!.\n";
	open(OUT,">$name[0].blast.new") or die "cannot open outfile due to $!.\n";


	my %hash;
	my %data;
	while (<BLOCK>)
	{
		#if ($_!~/^Gr/) {next;}
		my @arr=split(/\s+/,$_);
		$hash{$arr[0]}=$arr[2];
		$data{$arr[0]}=$arr[0];
	}
	while (<BLAST>)
	{
		my @arr=split(/\s+/,$_);


		if ($arr[0] eq $data{$arr[0]} && $arr[1] eq $hash{$arr[0]}) 
		{
			print OUT "$arr[0]\t$arr[1]\t$arr[2]\t$arr[3]\t$arr[4]\t$arr[5]\t$arr[6]\t$arr[7]\t$arr[8]\t$arr[9]\t$arr[10]\t$arr[11]\n";
		}
	}

}