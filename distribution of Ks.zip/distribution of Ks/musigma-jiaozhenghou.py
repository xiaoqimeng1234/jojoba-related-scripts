#!usr/bin/env python
# -*- coding: utf-8 -*-
'''
plot zhengtai from mu and sigma
'''
import numpy as np
import matplotlib.pyplot as plt
from matplotlib.patches import *
from itertools import islice
from scipy import stats
import re

fig = plt.figure(1,(16,10))#（16，10）为长宽比
f1=open(r'before.txt')
data=[]
for line in islice(f1, 1, None):
    a=line.strip().split('\t')
    data.append(a)
    print (len(a))
f1.close()
colors = { 'Vvi': 'green','Aya': 'm','Sch': 'deepskyblue','Vvi_Aya': 'Orange','Vvi_Sch': 'red','Aya_Sch': 'pink','SS': 'dodgerblue' }
names = { 'Vvi': 'V.vinifera(V)','Aya': 'A.yangbiense(A)','Sch': 'S.chinensis(S)','Vvi_Aya': 'V.vinifera vs A.yangbiense','Vvi_Sch': 'V.vinifera vs S.chinensis','Aya_Sch': 'A.yangbiense vs S.chinensis','SS': 'S.chinensis specific' }
t=np.arange(0.01,2.2,0.01)#第一个0.01改的为横坐标数字刻度，第二个数字1.8改的为横坐标长度，第三个数字0.01调大的话图像也变大
plt.xticks(fontsize=22)
plt.yticks(fontsize=22)
def qiuhe(a,b):
    c=[]
    for i in range(len(a)):
        c.append(a[i] + b[i])
    return c
for k in data:
    print (k)
    print(colors[k[0]])
    print(k[0])
    color=colors[k[0]]
    y=[0 for k in t]
    #print (int((len(k)-1)/3))
    for i in range(0,int((len(k)-1)/3)):
        print (k[0],k[3*i+2],k[3*i+3])		
        y1=stats.norm.pdf(t,float(k[3*i+2]),float(k[3*i+3]))*float(k[3*i+1])
        y=qiuhe(y,y1)
    if(len(k[0])>=4):
        style='--'
    else :
        style='-'
    plt.plot(t,y,linestyle=style,color=color,label=names[k[0]],linewidth=3)#xiandecuxi
plt.xticks(np.arange(min(t)-0.01,max(t), 0.2))
y_max=2.2#####图例的纵坐标
for k in range(0,len(data)):
    color=colors[data[k][0]]
    y=y_max-0.18*k#图例间的间距
    x=1.56#####调的是图例字母的位置，而非图例框框
    label=names[data[k][0]]
    if ' vs ' in label:
        x2=1.52#####
        plt.plot([x2-0.02,x2-0.017],[y,y],color=color,lw=3)
        plt.plot([x2-0.003,x2],[y,y],color=color,lw=3)        
    else :
        x1=1.52#图例的框框的位置
        plt.plot([x1-0.004,x1],[y,y],color=color,lw=10)

    align = dict(family='Times New Roman',style='italic',verticalalignment="center",horizontalalignment="left", fontsize=24)####图例
    plt.text(x,y,label,**align)  
align = dict(family='Times New Roman',style='italic',verticalalignment="center",horizontalalignment="center")
#plt.legend(fontsize='small',loc=0,shadow=True)
plt.text(1.1,-0.3,'Synonymous nucleotide subsititution(Ks)', fontsize=27,**align)
plt.text(-0.3,1.0,'kernel density of colinear gene pairs number',fontsize=27,rotation =90,**align)
plt.text(1.1,2.4,'After evolutionary rate correction',weight='bold',fontsize=30,**align)
plt.grid(True)
plt.savefig('before.png',dpi=1000)
plt.savefig('before.pdf',dpi=500)
#plt.show()
