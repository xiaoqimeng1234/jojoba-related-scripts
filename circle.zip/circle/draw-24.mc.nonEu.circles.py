### draw chromosome homology circles for eudicots with VV as reference, if VV is provided. If no vv chro is involved, it draws circles for other species

import re
from math import *
from pylab import *
from matplotlib.patches import *
from bez import *

##### circle parameters
GAP_RATIO = 4 #gaps between chromosome circle, chr:gap = 4: 1
r0, r1, r2 = 0.13, 0.01, 0.004
sm_radius=(0.005)/2 #telomere capping
figurefile = "oryza.alignment.para.circle"

figure(1, (10, 10))  ### define the a square, or other rectangle of the figure, if to produce an oval here
root =axes([0, 0, 1, 1])

fpchrolen = file("Vvi.lens");

fpmcfit = file("1.txt");

print "Usage: python draw.mc.circles.py\n"

chro2color = {"1": "#FFA07A", "2": "#7FFFD4", "3": "#FF69B4", "4": "#1E90FF", "5": "#00FF7F", "6": "#32CD32", "7": "#FFD700","8": "#D2691E","9": "#9932CC","10": "#7B68EE","11": "#DAA520", "12": "#BDB76B", "13": "red", "14": "blue", "15": "green", "16": "purple", "17": "cyan", "18": "yellow", "19": "sienna", "20": "#7FFFD4", "21": "#FF69B4", "22": "#1E90FF", "23": "#00FF7F", "24": "#1E90FF", "25": "#00FF7F", "26": "#32CD32", "27": "#FFD700","28": "#D2691E"}

### input chromosome length
chro2len = {}
labels = []
for row in fpchrolen:
    chro, length = row.split()
    chro = chro.capitalize()
    chro2len[chro] = int(length)
    labels.append(chro)
fpchrolen.close()
### full chro list
print "all chro", labels

def rad_to_coord(angle, radius):
    return radius*cos(angle), radius*sin(angle)

def to_deg(bp, total):
    # from basepair return as degree
    return bp*360./total

def to_radian(bp, total):
    # from basepair return as radian
#    print "to_radian", bp, total
    return radians(bp*360./total)

def plot_arc(start, stop, radius, clcl, lw):
    # start, stop measured in radian
    print "In plot_arc ", start, stop
    t = arange(start, stop, pi/720.)
    x, y = radius*cos(t), radius*sin(t)
    plot(x, y, color=clcl, linestyle = "-", alpha=.5, lw = lw)#circle line color

def plot_cap(angle, clockwise=True, radius=sm_radius):
    # angle measured in radian, clockwise is boolean
    if clockwise: t = arange(angle, angle+pi, pi/30.)
    else: t = arange(angle, angle-pi, -pi/30.)
    x, y = radius*cos(t), radius*sin(t)
    middle_r = (radius_a+radius_b)/2
    x, y = x + middle_r*cos(angle), y + middle_r*sin(angle)
    plot(x, y, "k-", alpha=.5)

def plot_arc_block(start, chain, radius):
    t = arange(start, start+blocklength, pi/720.)
    x,y = radius * cos(t), radius*sin(t)
    x1, y1 = (radius-blockthick) * cos(t), (radius-blockthick) * sin(t)
    plot(x, y, "b-", alpha=0.2)
#    plot(x1, y1, "g-", alpha=0.5)

    x0, y0 = radius*cos(start), radius*sin(start)
    x1,y1  = (radius-blockthick)*cos(start), (radius-blockthick)*sin(start)
#    plot([x0, y0], [x1, y1], "g-", lw=0.2)

    x0, y0 = radius*cos(start+blocklength), radius*sin(start+blocklength)
    x1,y1  = (radius-blockthick)*cos(start+blocklength), (radius-blockthick)*sin(start+blocklength)
#    plot([x0, y0], [x1, y1], "g-", lw=0.2)

fullchrolen = sum(chro2len.values())
chr_number = len(labels) # total number of chromosomes
GAP = fullchrolen/GAP_RATIO/chr_number # gap size in base pair
total_size = fullchrolen + chr_number * GAP # base pairs

start_list = [0]*chr_number
for i in xrange(1, chr_number):
    start_list[i] = start_list[i-1] + chro2len[labels[i-1]] + GAP
    print "chr ", i, start_list[i]
stop_list = [(start_list[i] + chro2len[labels[i]]) for i in xrange(chr_number)]

def transform_deg(ch, pos):
    return to_deg(pos + start_list[ch], total_size)

def transform_pt(ch, pos, r):
    # convert chromosome position to axis coords
#    print "transform", ch, pos, r
#    print "startlist", start_list[ch]
    rad = to_radian(pos + start_list[ch], total_size)
    return r*cos(rad), r*sin(rad)
def transform_pt2(rad, r):
    return r*cos(rad), r*sin(rad)

def plot_bez_inner(p1, p2, cl):
    print "inner"
    a, b, c = p1
    ex1x, ex1y = transform_pt(a, b, c)
    a, b, c = p2
    ex2x, ex2y = transform_pt(a, b, c)
    # Bezier ratio, controls curve, lower ratio => closer to center
    ratio = .5
    x = [ex1x, ex1x*ratio, ex2x*ratio, ex2x]
    y = [ex1y, ex1y*ratio, ex2y*ratio, ex2y]
    step = .01
    t = arange(0, 1+step, step)
    xt = Bezier(x, t)
    yt = Bezier(y, t)
    plot(xt, yt, color='gray', linestyle='-', lw=.02)

def plot_bez_outer(p1, p2, cl):
    print "outer"
    a, b, c = p1
    ex1x, ex1y = transform_pt(a, b, c)
    a, b, c = p2
    ex2x, ex2y = transform_pt(a, b, c)
    # Bezier ratio, controls curve, lower ratio => closer to center
    ratio = 1.1
    x = [ex1x, ex1x*ratio, ex2x*ratio, ex2x]
    y = [ex1y, ex1y*ratio, ex2y*ratio, ex2y]
    step = .01
    t = arange(0, 1+step, step)
    xt = Bezier(x, t)
    yt = Bezier(y, t)
    plot(xt, yt, '-', color=cl, lw=.1)

def plot_bez_Ks(rad1, r1, rad2, r2, col):
    print "bez Ks 1"
    ex1x, ex1y = transform_pt2(rad1, r1)
    ex2x, ex2y = transform_pt2(rad2, r2)
    ratio = 0.5
    x = [ex1x, ex1x*ratio, ex2x*ratio, ex2x]
    y = [ex1y, ex1y*ratio, ex2y*ratio, ex2y]
    step = .01
    t = arange(0, 1+step, step)
    xt = Bezier(x, t)
    yt = Bezier(y, t)
    plot(xt, yt, '-', color=col, lw=.1)

def plot_bez_Ks2(rad1, r1, rad2, r2, col):
    print "bez Ks 2"
    ex1x, ex1y = transform_pt2(rad1, r1)
    ex2x, ex2y = transform_pt2(rad2, r2)
    ratio = 0.5
    sita = pi/2
    if ex1x != ex2x:
	sita = atan((ex2y-ex1y)/(ex2x-ex1x))
    d = sqrt((ex2x-ex1x)**2+(ex2y-ex1y)**2)
    L = d * ratio
    P1x = ex1x + L*sin(sita)
    P1y = ex1y - L*cos(sita)
    P2x = ex2x + L*sin(sita)
    P2y = ex2y - L*cos(sita)
    step = .01
    t = arange(0, 1+step, step)
    x=[ex1x, P1x, P2x, ex2x]
    y=[ex1y, P1y, P2y, ex2y]
    xt = Bezier(x,t)
    yt = Bezier(y,t)
    plot(xt, yt, '-', color = col, lw = 0.1)

def plot_sector(s):
    # block_id, chr_id, start_bp, stop_bp
    block_id, chr_id, start_bp, stop_bp = s
    theta0, theta1 = transform_deg(chr_id, start_bp), transform_deg(chr_id, stop_bp)
    dtheta = .1
    p1 = Wedge((0, 0), radius_a, theta0, theta1, dtheta=dtheta, fc="w", ec="w")
    p2 = Wedge((0, 0), radius_b, theta0, theta1, dtheta=dtheta, fc=colors[block_id], ec="w")
    root.add_patch(p2)
    root.add_patch(p1)

print "r0r1r2", r0, r1, r2
### input mcscan data
row = fpmcfit.readline()
### read in pair file
gene2alignpos = {}
gene2wgdpara = {}
rowno = 0
for row in fpmcfit:
#    print "thisrow", row
    item = row.split("\t")
    chropos = item[0].split("=")
    (c2, p2, s2) = (-1, -1, -1)

#    print "position is ", chropos[0], chropos[1]
    sbgene1 = ""
    sbgene2 = ""
    for i in xrange(1, min(len(item), 31)):############add blocks
        if len(item[i]) > 6:
           xx1, yy1 = transform_pt(int(chropos[0]), int(chropos[1]), r0+(i-2)*(r1+r2))
           xx2, yy2 = transform_pt(int(chropos[0]), int(chropos[1]), r0+(i-2)*(r1+r2)+r1)

           if item[i].find("g") == -1:
                 continue
           itemN = item[i].split("/")
           for j in xrange(len(itemN)):
                 if itemN[j].find("g") != -1:
                   item[i] = itemN[j]
                   break
           chro = item[i].split("g")[0]
           chro = re.sub('\D', '', chro)
           chro = re.sub('^0', '', chro)
	   color = chro2color[chro]
           print "the i is ", i, item[i], color
           plot([xx1, xx2], [yy1, yy2], color=color, linestyle='-', lw = .02)
           
           if i==1:
              (c2, p2, s2) =(int(chropos[0]), int(chropos[1]), r0-r1-r1)
              gene2alignpos[item[i]] = (c2, p2, s2)
              sbgene1 = item[i]
#              print "sbgene1 is ", sbgene1

           if i==6 or i==11:
              sbgene2 = item[i]
#              print "sbgene2 is ", sbgene2

#    print "sbgenes ", sbgene1, " ", sbgene2

    if sbgene1 != "" and sbgene2 != "":
       gene2wgdpara[sbgene1 + " " + sbgene2] = 1
#       print "genepair", sbgene1, sbgene2
    rowno = rowno + 1
        #if rowno==1000:
#break
fpmcfit.close()

### draw colinear lines
for genepair in gene2wgdpara.keys():
    print "thisgenepair", genepair
    gene1, gene2 = genepair.split(' ')
    if gene1 in gene2alignpos and gene2 in gene2alignpos:
       plot_bez_inner(gene2alignpos[gene1], gene2alignpos[gene2], "red")

# the chromosome layout
j = 0
for start, stop in zip(start_list, stop_list):
    start, stop = to_radian(start, total_size), to_radian(stop, total_size)

    print "chropos ", start, stop, r0-r1

    plot_arc(start, stop, r0-r1-0.01, clcl="black", lw=1)
    for i in range(-1, 15):#############add circle line
       if i ==-1 or i==11:
          plot_arc(start, stop, r0+i*(r1+r2), clcl = "black", lw=1)       
       elif i==0 or i==12:
          plot_arc(start, stop, r0+i*(r1+r2), clcl = "#20B2AA", lw=1)
       elif i==1 or i==13:
          plot_arc(start, stop, r0+i*(r1+r2), clcl = "#A0522D", lw=1)
       elif i==2 or i==14:
          plot_arc(start, stop, r0+i*(r1+r2), clcl = "#FFA07A", lw=1)
       elif i==3 or i==15:
          plot_arc(start, stop, r0+i*(r1+r2), clcl = "#32CD32", lw=1)
       elif i==4 or i==16:
          plot_arc(start, stop, r0+i*(r1+r2), clcl = "#FFB6C1", lw=1)
       elif i==5 or i==17:
          plot_arc(start, stop, r0+i*(r1+r2), clcl = "#7B68EE", lw=1)
       elif i==6 or i==18:
          plot_arc(start, stop, r0+i*(r1+r2), clcl = "#C71585", lw=1)
       elif i==7 or i==19:
          plot_arc(start, stop, r0+i*(r1+r2), clcl = "#808000", lw=1)
       elif i==8 or i==20:
          plot_arc(start, stop, r0+i*(r1+r2), clcl = "#4682B4", lw=1)
       elif i==9 or i==21:
          plot_arc(start, stop, r0+i*(r1+r2), clcl = "#6A5ACD", lw=1)
       elif i==10 or i==22:
          plot_arc(start, stop, r0+i*(r1+r2), clcl = "#F4A460", lw=1)
       elif i==23:
          plot_arc(start, stop, r0+i*(r1+r2), clcl = "black", lw=1)


#        plot_arc(start, stop, r0+i*(r1+r2))
    # telemere capping
    #plot_cap(start, clockwise=False)
    #plot_cap(stop)
    # chromosome labels
    label_x, label_y = rad_to_coord(start+0.01, r0*0.75)
    plot(label_x, label_y, 'yo', markersize=10, lw=0.2)
    text(label_x, label_y, labels[j], horizontalalignment="center", verticalalignment="center", fontsize = 8, color = 'black')
    j+=1


### draw the circle marker text
label_x, label_y = rad_to_coord(0, r0)
text(label_x-0.015, label_y-0.007, "V  A  S  S  S  V  A  S  S  S  V  A  S  S  S  ", verticalalignment="center", fontsize = 8)

###
#for i in xrange(1, 24):
#		label_x, label_y = rad_to_coord(0.68, r0+(i-1)*(r1+r2)*0.56+0.011)
#		if i==1 or i%4==0 or i==24:
#				text(label_x-0.021, label_y-0.015, i, horizontalalignment="center", verticalalignment="center", fontsize = 8)
#		else:
#				text(label_x-0.02, label_y-0.0125, ".", horizontalalignment="center", verticalalignment="center", fontsize = 8)

#### draw tick showing scale of chromosomes
for i in xrange(chr_number):
   pos = 0
   while pos < chro2len[labels[i]]:
      xx1, yy1 = transform_pt(i, int(pos), r0-1.8*r1)
      xx2, yy2 = transform_pt(i, int(pos), r0-r1-0.01)
      plot([xx1, xx2], [yy1, yy2], "grey", lw = .2)
      pos = pos + 2000

#

align = dict(horizontalalignment="center", fontsize=10)
startx, starty = -.2, -.40
square = .015

root.text(startx-square*15, starty, "Ch#", align)

root.add_patch(Rectangle((startx-14*square, starty), 2*square, square, fc=chro2color["1"]))
root.text(startx-13*square, starty-square, "$1$", align)
root.add_patch(Rectangle((startx-12*square, starty), 2*square, square, fc=chro2color["2"]))
root.text(startx-11*square, starty-square, "$2$", align)
root.add_patch(Rectangle((startx-10*square, starty), 2*square, square, fc=chro2color["3"]))
root.text(startx-9*square, starty-square, "$3$", align)
root.add_patch(Rectangle((startx-8*square, starty), 2*square, square, fc=chro2color["4"]))
root.text(startx-7*square, starty-square, "$4$", align)
root.add_patch(Rectangle((startx-6*square, starty), 2*square, square, fc=chro2color["5"]))
root.text(startx-5*square, starty-square, "$5$", align)
root.add_patch(Rectangle((startx-4*square, starty), 2*square, square, fc=chro2color["6"]))
root.text(startx-3*square, starty-square, "$6$", align)
root.add_patch(Rectangle((startx-2*square, starty), 2*square, square, fc=chro2color["7"]))
root.text(startx-1*square, starty-square, "$7$", align)
root.add_patch(Rectangle((startx, starty), 2*square, square, fc=chro2color["8"]))
root.text(startx+1*square, starty-square, "$8$", align)
root.add_patch(Rectangle((startx+2*square, starty), 2*square, square, fc=chro2color["9"]))
root.text(startx+3*square, starty-square, "$9$", align)
root.add_patch(Rectangle((startx+4*square, starty), 2*square, square, fc=chro2color["10"]))
root.text(startx+5*square, starty-square, "$10$", align)
root.add_patch(Rectangle((startx+6*square, starty), 2*square, square, fc=chro2color["11"]))
root.text(startx+7*square, starty-square, "$11$", align)
root.add_patch(Rectangle((startx+8*square, starty), 2*square, square, fc=chro2color["12"]))
root.text(startx+9*square, starty-square, "$12$", align)
root.add_patch(Rectangle((startx+10*square, starty), 2*square, square, fc=chro2color["13"]))
root.text(startx+11*square, starty-square, "$13$", align)
root.add_patch(Rectangle((startx+12*square, starty), 2*square, square, fc=chro2color["14"]))
root.text(startx+13*square, starty-square, "$14$", align)
root.add_patch(Rectangle((startx+14*square, starty), 2*square, square, fc=chro2color["15"]))
root.text(startx+15*square, starty-square, "$15$", align)
root.add_patch(Rectangle((startx+16*square, starty), 2*square, square, fc=chro2color["16"]))
root.text(startx+17*square, starty-square, "$16$", align)
root.add_patch(Rectangle((startx+18*square, starty), 2*square, square, fc=chro2color["17"]))
root.text(startx+19*square, starty-square, "$17$", align)
root.add_patch(Rectangle((startx+20*square, starty), 2*square, square, fc=chro2color["18"]))
root.text(startx+21*square, starty-square, "$18$", align)
root.add_patch(Rectangle((startx+22*square, starty), 2*square, square, fc=chro2color["19"]))
root.text(startx+23*square, starty-square, "$19$", align)

root.add_patch(Rectangle((startx+24*square, starty), 2*square, square, fc=chro2color["20"]))
root.text(startx+25*square, starty-square, "$20$", align)
root.add_patch(Rectangle((startx+26*square, starty), 2*square, square, fc=chro2color["21"]))
root.text(startx+27*square, starty-square, "$21$", align)
root.add_patch(Rectangle((startx+28*square, starty), 2*square, square, fc=chro2color["22"]))
root.text(startx+29*square, starty-square, "$22$", align)
root.add_patch(Rectangle((startx+30*square, starty), 2*square, square, fc=chro2color["23"]))
root.text(startx+31*square, starty-square, "$23$", align)
root.add_patch(Rectangle((startx+32*square, starty), 2*square, square, fc=chro2color["24"]))
root.text(startx+33*square, starty-square, "$24$", align)
root.add_patch(Rectangle((startx+34*square, starty), 2*square, square, fc=chro2color["25"]))
root.text(startx+35*square, starty-square, "$25$", align)
root.add_patch(Rectangle((startx+36*square, starty), 2*square, square, fc=chro2color["26"]))
root.text(startx+37*square, starty-square, "$26$", align)
root.add_patch(Rectangle((startx+38*square, starty), 2*square, square, fc=chro2color["27"]))
root.text(startx+39*square, starty-square, "$27$", align)
root.set_xlim(-.5, .5)
root.set_ylim(-.5, .5)
root.set_axis_off()
savefig(figurefile + ".pdf", dpi=300)
savefig(figurefile + ".png", dpi=500)


